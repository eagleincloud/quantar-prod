import json
import boto3
import uuid
import pymysql
from datetime import datetime
from urllib.parse import unquote_plus

def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        
def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        
def get_qs_user_id(sourceKey):
    identity = sourceKey.split("/")[0]
    client = boto3.client('cognito-idp')
    response = client.list_users(
        UserPoolId='eu-west-2_8ne74JB2A',
        Filter="sub = '"+identity+"'"
    )

    return response['Users']

def get_team_of_user(id):
    query=''' select TID from quantar_user_management.quantar_user where UID ='{}';'''.format(id)
    data=run_select_query(query)
    return data
    

def add_custom_s3(bucketPath,uid,file_size,is_team):
    try:
        # ival=bucketPath.split('/')
        # if len(ival)<6:
        #     return False
            
        temp=0;
        query=''' select UID from quantar_user_management.quantar_user; '''
        data=run_select_query(query)
        print("Idris: ",data)
        for x in data:
            if x[0] == uid:
                print("User Found")
                temp=temp+1;
                break;
        
        if temp==0:
            raise Exception("User Not Found")
            
        else:
            pfinal_team = None
            if is_team:
                team=get_team_of_user(uid)
                pfinal_team=team[0][0]
            file_name=bucketPath.split('/')[-1]
            query=''' INSERT INTO quantar_user_management.quantar_user_dataset(UID,TID,DatasetName,DatasetS3Path,ConnectorName,
                dataset_size,Status,LastUpdateTimestamp) VALUES(%s,%s,%s,%s,'CUSTOM FILE',%s,'Active',now()); '''
            return run_insert_update_query(query, (uid, pfinal_team, file_name, bucketPath, str(file_size)+"bytes"))
        
    except Exception as e:
        print(str(e))
        return False
        
def check_dataset_quantity(sub):
    query = "select qu.TID from quantar_user qu where qu.UID like '%{}%';".format(
            sub)
    #print(query)
    data = run_select_query(query)
    print(data)
    # If Team is available
    if data[0][0]:
        query = """select qpm.dataSetCount from quantar_package_mgmt qpm 
                    join 
                    (select qph.PackageID 
                    from quantar_payment_history qph 
                    where qph.UID in (select UID from quantar_user where TID = '{}') 
                    and qph.PaymentStatus = 'Success' order by LastUpdateTimestamp Desc limit 1) pid on qpm.PacakageID = pid.PackageID;""".format(data[0][0])
        latest_pack_dataset_count = 0
        if len(run_select_query(query)):
            latest_pack_dataset_count = run_select_query(query)[0][0]

        query = """select count(TID)  from quantar_user_dataset qud where TID = '{}';""".format(data[0][0])
        uploaded_dataset_count = run_select_query(query)[0][0]
        print(uploaded_dataset_count)

        if latest_pack_dataset_count == 0:
            raise Exception('Purchase a Plan.')

        if uploaded_dataset_count == latest_pack_dataset_count:
            raise Exception('Reached the plan dataset limit.') 
    else: #For individual account
        query = """select qpm.dataSetCount from quantar_package_mgmt qpm 
                    join 
                    (select qph.PackageID 
                    from quantar_payment_history qph 
                    where qph.UID = '{}'
                    and qph.PaymentStatus = 'Success' order by LastUpdateTimestamp Desc limit 1) pid on qpm.PacakageID = pid.PackageID;""".format(sub)
        latest_pack_dataset_count = 0
        if len(run_select_query(query)):
            latest_pack_dataset_count = run_select_query(query)[0][0]

        query = """select count(UID)  from quantar_user_dataset qud where UID = '{}';""".format(sub)
        uploaded_dataset_count = run_select_query(query)[0][0]
        print("uploaded_dataset_count", uploaded_dataset_count)
        print("latest_pack_dataset_count", latest_pack_dataset_count)
        if latest_pack_dataset_count == 0:
            raise Exception('Purchase a Plan.')

        if uploaded_dataset_count == latest_pack_dataset_count:
            raise Exception('Reached the plan dataset limit.')    
    
def get_s3_object_tag_team_status(bucket_name, key):
    client = boto3.client('s3')
    response = client.get_object_tagging(
    Bucket=bucket_name,
    Key=key)
    
    tag_list = response['TagSet']
    
    print("Tag List: ",tag_list)
    is_team = False
    
    if tag_list:
        for i in tag_list:
            if i['Key'] == 'is_team':
                is_team = i['Value']
    
    return is_team
    
def lambda_handler(event, context):
    print(event)
    try:
        sourceKey = unquote_plus(event['Records'][0]['s3']['object']['key'])
        uid=sourceKey.split('/')[0]
        print(uid)
        check_dataset_quantity(uid)
        bucketName = unquote_plus(event['Records'][0]['s3']['bucket']['name'])
        bucketPath = "s3://"+bucketName+"/"+"/".join(sourceKey.split('/')[0:2])
        custom_bucketPath = "s3://"+bucketName+"/"+"/".join(sourceKey.split('/'))
        print(bucketPath)
        user = get_qs_user_id(sourceKey)
        size=event['Records'][0]['s3']['object']['size']
        dbName = user[0]['Username']
        print("DB_Name: ",dbName)
        client = boto3.client('glue')
        id = uuid.uuid4()
        crawlerName = 'qspoc-crawler-'+str(id)
        
        print("crawlerName:", crawlerName)
        
        is_team = get_s3_object_tag_team_status(bucketName, sourceKey)
        
        print('is_team: ', is_team)
        
        if is_team:
            dbName = get_team_of_user(uid)
        
        db_response=add_custom_s3(custom_bucketPath,uid,size,is_team)
        print(db_response)
        
        response = client.create_crawler(
            Name=crawlerName,
            Role='quicksight-poc-glue-role',
            DatabaseName=dbName,
            Description='Crawler generated for Quick Sight POC',  # optional
            Targets={
                'S3Targets': [
                    {
                        'Path': bucketPath,
                    },
                ],
            },
        )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            response = client.start_crawler(Name=crawlerName)
            print("Crawler Response", response)
            if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                return {
                    'statusCode': 200,
                    'crawlerName': crawlerName
                }
            else:
                return {
                    'statusCode': 400,
                    'crawlerName': crawlerName
                }
        else:
            return {
                'statusCode': 400,
                'body': crawlerName
            }
    except Exception as e:
        print("Error Message: ", str(e))
