import json
import boto3
import secrets

def verify_email_identity(contact):
    ses_client = boto3.client("ses", region_name="eu-west-2")
    response = ses_client.verify_email_identity(
        EmailAddress=contact
    )

def send_plain_email(contact, secretLoginCode):
    ses_client = boto3.client("ses", region_name="eu-west-2")
    CHARSET = "UTF-8"

    response = ses_client.send_email(
        Destination={
            "ToAddresses": [
                contact,
            ],
        },
        Message={
            "Body": {
                "Text": {
                    "Charset": CHARSET,
                    "Data": "Your Verification code is {}.".format(secretLoginCode),
                }
            },
            "Subject": {
                "Charset": CHARSET,
                "Data": "Password Mail",
            },
        },
        Source="tech@quantar.io",
    )     

def lambda_handler(event, context):
    
    print(event)
    
    #------------Test Code Start Here-------------
    
    # contact=event['email']
    # secretLoginCode=event['code']
    
    # try:
    #     send_plain_email(contact, secretLoginCode)
    # except Exception as e:
    #     print(str(e))
    
    #---------------Test Code End Here----------------
    
    #Create Challenge and then Send Notification
    response = event.get('response')
    request = event.get('request')
    session = request.get('session')
    if (not session) or len(session) == 0:
        secretsGenerator = secrets.SystemRandom()
        secretLoginCode = secretsGenerator.randrange(100000, 999999)  # create OTP here
        
        # send Notification
        contact = request.get('userAttributes').get('email')
        try:
            send_plain_email(contact, secretLoginCode)
        except Exception as e:
            print(str(e))
            # verify_email_identity(contact)
        #secretLoginCode = 12345
        
    else:
        previousChallenge = session[0]
        secretLoginCode = previousChallenge.get('challengeMetadata')
        
    response.update({
            'privateChallengeParameters': {'answer': secretLoginCode},
            'challengeMetadata': secretLoginCode,
            'publicChallengeParameters': {
                'answer': secretLoginCode
            }
        })
    return event
