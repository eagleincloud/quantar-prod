import json
import boto3
import pymysql

client = boto3.client('cognito-idp')
def lambda_handler(event, context):
    print(event)
    if event['triggerSource'] == 'PostConfirmation_ConfirmSignUp':
        username = event['userName']
        uid = event['request']['userAttributes']['sub']
        email = event['request']['userAttributes']['email']
        response = client.admin_get_user(
        UserPoolId='eu-west-2_8ne74JB2A',
        Username=username
        )
        name = username
        Role = 'Individual User'
        attribute_list = response['UserAttributes']
        for attribute in attribute_list:
            if attribute['Name'] == 'name':
                name = attribute['Value']
            if attribute['Name'] == 'custom:Role':
                Role = attribute['Value']    
        
        insertUser(username, uid, name, email, Role)
    
    return event


def insertUser(username, uid, firstname, email, Role):
    # To connect MySQL database
    try:
        conn = pymysql.connect(
        host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
        user='quantar_admin', 
        password = "fuSPFRpovgpLpjP8lVBO",
        db='quantar_user_management',
        )
      
        cur = conn.cursor()
        query = """ INSERT INTO quantar_user_management.quantar_user
                    (Username, UID, FirstName, EmailID, UserAddedByID, URID, LastUpdateTimestamp)
                    VALUES(%s, %s, %s, %s, %s, %s, now()); """
        # Insert query
        cur.execute(query, (username, uid, firstname, email,'signup', Role))
        conn.commit()
    except Exception as e:
        print(str(e))
    finally:
        conn.close()