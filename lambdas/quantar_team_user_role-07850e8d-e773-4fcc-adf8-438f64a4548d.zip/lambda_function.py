import pymysql
import pandas as pd


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def list_roles():
    try:
        query = """SELECT * FROM quantar_user_management.quantar_user_roles;"""
        data = run_select_query(query, None)
        df = pd.DataFrame(data, columns=[
                          'UserRoleName', 'URID'])
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        return {}


def lambda_handler(event, context):
    try:
        data = list_roles()
        return {
            'statusCode': 200,
            'data': data
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': 'Failure: '+str(e)
        }
