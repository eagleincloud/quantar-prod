import pymysql

def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        raise Exception("Database Error.")
    finally:
        conn.close()


def update_mfa_status(sub, status):
    query = """UPDATE quantar_user_management.quantar_user
            SET  mfa_status=%s WHERE UID=%s; """
    run_insert_update_query(query, (status, sub))


def lambda_handler(event, context):
    try:
        mfa_status = event['mfa_status']
        sub = event['sub']
        update_mfa_status(sub, mfa_status)
        return {
            'statusCode': 200,
            'body': 'MFA status set to {}.'.format(str(mfa_status))
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'error': 'Problem to update mfa status. Message: {0}'.format(str(e))
        }

