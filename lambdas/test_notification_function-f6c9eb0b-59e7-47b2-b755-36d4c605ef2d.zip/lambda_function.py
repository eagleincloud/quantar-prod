import json
import boto3
import pymysql


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def insert_user_details(UID, message):
    query = """INSERT INTO quantar_user_management.quantar_user_message
                (UID, message_status, message, update_date)
                VALUES(%s, 1, %s, now());"""
    response = run_insert_update_query(
        query, (UID, message))
    return response


def lambda_handler(event, context):
    try:
        UID = event['sub']
        message = event['message']
        insert_user_details(UID, message)
        
        client = boto3.client('lambda')
        response = client.invoke(FunctionName='arn:aws:lambda:eu-west-2:625302196318:function:quantar_push_user_notification', InvocationType='Event')
    
        return {
            'statusCode': 200,
            'body': 'Message Entered.'
        }

    except Exception as e:
        print("Error: ", str(e))
        return {
            'statusCode': 400,
            'body': 'Error: {}'.format(str(e))
        }
