import pymysql


def run_insert_update_delete_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def delete_connection_id_in_database(connectionId):
    query = """DELETE FROM quantar_user_management.quantar_notification_websocket_connid WHERE connectionid=%s;"""
    run_insert_update_delete_query(
        query, (connectionId,))


def lambda_handler(event, context):
    try:
        connectionId = event['requestContext']['connectionId']

        delete_connection_id_in_database(connectionId)
        return {}
    except Exception as e:
        print("Error {}".format(str(e)))
