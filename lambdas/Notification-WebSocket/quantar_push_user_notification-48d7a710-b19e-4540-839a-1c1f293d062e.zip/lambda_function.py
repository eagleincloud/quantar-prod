import pymysql
import pandas as pd
import boto3
import json


def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def update_message_status(record):
    # To connect MySQL database
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """ UPDATE quantar_user_management.quantar_user_message SET message_status=0 WHERE id=%s;"""
        # Insert query
        cur.execute(query, (record['id'],))
        conn.commit()
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')
    finally:
        conn.close()


def push_notification(record):
    websocket_url = "https://o1rr0uxqah.execute-api.eu-west-2.amazonaws.com/production"
    api_gateway_client = boto3.client(
        "apigatewaymanagementapi", endpoint_url=websocket_url)
    api_gateway_client.post_to_connection(
        ConnectionId=record['connectionid'], Data=json.dumps(record['message']))


def get_messages_to_send():
    try:
        query = """SELECT qum.id, qum.UID, qum.message , qnwcid.connectionid 
                FROM quantar_user_management.quantar_user_message qum 
                INNER JOIN quantar_user_management.quantar_notification_websocket_connid qnwcid 
                ON qum.UID = qnwcid.UID 
                where qum.message_status = 1;;"""
        print(query)
        data = run_select_query(query)
        return data
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')


def lambda_handler(event, context):
    try:
        data = get_messages_to_send()
        df = pd.DataFrame(
            data, columns=['id', 'UID', 'message', 'connectionid'])
        message_list = df.to_dict('records')

        if message_list:
            for record in message_list:
                try:
                    push_notification(record)
                    #update_message_status(record)
                except Exception as e:
                    print("Error Sending message to user: {}".format(
                        record['UID']))
                    print(str(e))
    except Exception as e:
        print(str(e))
