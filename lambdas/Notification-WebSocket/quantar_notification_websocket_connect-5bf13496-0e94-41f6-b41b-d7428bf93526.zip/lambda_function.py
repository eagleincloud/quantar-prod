import pymysql


def run_insert_update_delete_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def insert_connection_id_in_database(sub, connectionId):
    query = """INSERT INTO quantar_user_management.quantar_notification_websocket_connid
               (UID, connectionid) VALUES(%s, %s);"""
    run_insert_update_delete_query(
        query, (sub, connectionId))


def lambda_handler(event, context):
    try:
        print(event)
        connectionId = event['requestContext']['connectionId']
        sub = event["queryStringParameters"]["sub"]

        insert_connection_id_in_database(sub, connectionId)
        return {
        "statusCode": 200,
        "headers": event['headers'],
        "body": 'Connected Successfully.',
        "isBase64Encoded": False
            }
    except Exception as e:
        print("Error {}".format(str(e)))
        return {
        "statusCode": 400,
        "headers": event['headers'],
        "body": 'Error in Connection.',
        "isBase64Encoded": False
            }
        
