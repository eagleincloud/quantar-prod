import json
import boto3
import pymysql
import pandas as pd

def run_delete_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        
def get_user_role(UID):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """SELECT URID as user_role, Username 
                   FROM quantar_user_management.quantar_user WHERE UID = '{}';""".format(UID)
        cur.execute(query)
        records = cur.fetchone()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def remove_user_from_team(username, uid):
    # To connect MySQL database
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )

        cur = conn.cursor()
        query = """ DELETE FROM quantar_user_management.quantar_user
                    where Username=%s and UID=%s; """
        # Insert query
        cur.execute(query, (username, uid))
        conn.commit()
    except Exception as e:
        print(str(e))
    finally:
        conn.close()


def deactivate_team_account(uid, username):
    print('Deactivating Team Account UID: ',uid)
    # To connect MySQL database
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """ UPDATE quantar_user_management.quantar_user SET TID = null, team_account_status=0, team_account_exist=0 WHERE UID=%s; """
        # Insert query
        cur.execute(query, (uid,))
        conn.commit()
    except Exception as e:
        print(str(e))
    finally:
        conn.close()


def get_account_details(UID):
    try:
        query = "SELECT team_account_status, individual_account_status, team_account_exist, individual_account_exist FROM quantar_user_management.quantar_user where UID = '{}';".format(
            UID)
        print(query)
        data = run_select_query(query)
        print(data)
        df = pd.DataFrame(data, columns=[
                          'team_account_status', 'individual_account_status', 'team_account_exist', 'individual_account_exist'])
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        raise Exception('Database Error',str(e))

def get_user_tid(uid):
    query="""select TID from quantar_user_management.quantar_user where UID = '{}' );""".format(uid)
    data = run_select_query(query)
    return data[0][0]
    
def check_user_datasets(uid):
    query="""SELECT DID FROM `quantar_user_dataset` WHERE UID='{}';""".format(uid)
    data = run_select_query(query)
    return data
    
def delete_user_dataset(uid):
    query="""DELETE FROM `quantar_user_dataset` WHERE UID=%s;"""
    run_delete_query(query, (uid))
    
def delete_team_only_account(uid, username):
    count=check_user_datasets(uid)
    print(count)
    
    if not count:
        print("Deleting User")
        remove_user_from_team(username, uid)
        client = boto3.client('cognito-idp')
        response = client.admin_delete_user(
            UserPoolId='eu-west-2_8ne74JB2A',
            Username=username
        )
    else:
        print("Deleting datasets, then deleting User")
        delete_user_dataset(uid)
        remove_user_from_team(username, uid)
        client = boto3.client('cognito-idp')
        response = client.admin_delete_user(
        UserPoolId='eu-west-2_8ne74JB2A',
        Username=username
    )
    


def get_user_details(username):
    client = boto3.client('cognito-idp')

    response = client.admin_get_user(
        UserPoolId='eu-west-2_8ne74JB2A',
        Username=username
    )

    attribute_list = response['UserAttributes']
    print(attribute_list)
    for attribute in attribute_list:
        if attribute['Name'] == 'sub':
            uid = attribute['Value']
        if attribute['Name'] == 'custom:Role':
            if attribute['Value'] == 'Team Manager':
                raise Exception("Team Manger cannot be deleted.")
            

    acc_details = get_account_details(uid)
    
    print("Acc_details: ",acc_details)

    if acc_details:
        if acc_details[0]['individual_account_exist'] == 0 and acc_details[0]['team_account_status'] == 1:
            delete_team_only_account(uid, username)
        elif acc_details[0]['individual_account_exist'] == 1 and acc_details[0]['team_account_status'] == 1:
            deactivate_team_account(uid, username)
    else:
        raise Exception('No User Exist.')

def get_team_id(UID):
    try:
        query = """SELECT Username, UID, TID, FirstName as Name, URID as user_role , EmailID
                   FROM quantar_user_management.quantar_user WHERE team_account_status = 1 and TID in 
                   (select TID from quantar_user_management.quantar_user where UID = '{}' );""".format(UID)
        data = run_select_query(query)
        return data
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')


def lambda_handler(event, context):
    try:
        username = event['username']
        UID = event['sub']  # get method
        role, db_username = get_user_role(UID)
        print(role)
        print(db_username)
        if db_username == username:
            return {
                'statusCode': 400,
                'body': 'User cannot delete its own account.'
            }
        if role in ["Team User" , "Individual User"]:
            return {
                'statusCode': 400,
                'body': 'User does not have specefic Permission'
            }
        get_user_details(username)
        data = get_team_id(UID)
        df = pd.DataFrame(
            data, columns=['Username', 'UID', 'TID', 'Name', 'User_Role', 'EmailID'])
        
        return {
            'statusCode': 200,
            'message': 'User {} deleted successfully'.format(username),
            'body': df.to_dict('records')
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': 'Exception in deletion process. Error Message:- {}'.format(str(e))
        }
