import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    # user_pool_id = "eu-west-2_8ne74JB2A"
    try:
        print(event)
        session=event["Session"]
        user_name=event["username"]
        password=event["new_password"]
        print(password)
      
        aws_client = boto3.client('cognito-idp')
        
        response = aws_client.respond_to_auth_challenge(
        ClientId='2uhegs5q628bk5q3rcop20jm4j',
        ChallengeName='NEW_PASSWORD_REQUIRED',
        Session=session,
        ChallengeResponses={
            'NEW_PASSWORD': password,
            'USERNAME': user_name
        })
        
        print(response)
        return {
            'statusCode': 200,
            'message': 'Password Changed Successfully.',
        }
    
    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
