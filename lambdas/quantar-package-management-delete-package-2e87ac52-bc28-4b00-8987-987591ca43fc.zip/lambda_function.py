import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta
import pandas as pd


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def delete_package_details(package_id):
    try:
        query = """Delete FROM quantar_user_management.quantar_package_mgmt where PacakageID = %s;"""
        return run_insert_update_query(query, (package_id,))
    except Exception as e:
        print(str(e))
        return False


def lambda_handler(event, context):
    try:
        operation_type = event['operation_type']
        if operation_type == 'delete':
            package_id = event['package_id']
            response = delete_package_details(package_id)
            return {
                'statusCode': 200,
                'isPackageDeleted': response
            }
        else:
            raise Exception('Wrong Operation')
    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
