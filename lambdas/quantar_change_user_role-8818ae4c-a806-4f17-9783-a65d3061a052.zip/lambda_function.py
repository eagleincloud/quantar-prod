import boto3
import pymysql



def change_user_role(role, username):
    # To connect MySQL database
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """ UPDATE quantar_user_management.quantar_user SET URID=%s WHERE Username=%s;"""
        # Insert query
        cur.execute(query, (role, username))
        conn.commit()
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')
    finally:
        conn.close()


def lambda_handler(event, context):
    try:
        username = event['username']
        role = event['role']
        
        if role == "Team User":
            raise Exception("User Not Allowed")
            
        else:
            client = boto3.client('cognito-idp')
            response = client.admin_update_user_attributes(
                UserPoolId='eu-west-2_8ne74JB2A',
                Username=username,
                UserAttributes=[
                    {
                        'Name': 'custom:Role',
                        'Value': role
                    },
                ]
            )
            change_user_role(role, username)
            return {
                'statusCode': 200,
                'body': 'Role Changed Successfully.'
            }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body': 'Exception in role change process. Message: {0}'.format(str(e))
        }
