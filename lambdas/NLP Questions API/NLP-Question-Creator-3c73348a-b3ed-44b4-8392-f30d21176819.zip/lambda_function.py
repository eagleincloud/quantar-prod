import json


def lambda_handler(event, context):
    print(event)
    numeric_list = ['id', 'Salary']
    string_list = ['Name', 'Department', 'Country']

    text_question = event['text_question']
    if "find all" in text_question:
        if "where" in text_question:
            word_list = text_question.strip(" ").split(" ")
            txt_len = len(word_list)
            if txt_len == 3:
                all_columns = numeric_list + string_list
                return {
                    'statusCode': 200,
                    'body': json.dumps(["find all where "+x for x in all_columns])
                }
            elif txt_len == 4:
                if word_list[-1] in numeric_list:
                    operation_list = ['is', 'greater than equal to',
                                      'less than equal to', 'less than', 'greater than']
                    return {
                        'statusCode': 200,
                        'body': json.dumps([text_question+" "+x for x in operation_list])
                    }
                elif word_list[-1] in string_list:
                    operation_list = 'like'
                    return {
                        'statusCode': 200,
                        'body': json.dumps([text_question+" "+operation_list])
                    }
        return {
            'statusCode': 200,
            'body': json.dumps(['find all where'])
        }
    elif "sum of" in text_question:
        return agg_handler("sum of", text_question, numeric_list, string_list)
    elif "min of" in text_question:
        return agg_handler("min of", text_question, numeric_list, string_list)
    elif "max of" in text_question:
        return agg_handler("max of", text_question, numeric_list, string_list)
    elif "avg of" in text_question:
        return agg_handler("avg of", text_question, numeric_list, string_list)
    elif "count of" in text_question:
        return agg_handler("count of", text_question, numeric_list, string_list)
    return {
        'statusCode': 200,
        'body': json.dumps(['find all', 'sum of', 'min of', 'max of', 'count of', 'avg of'])
    }


def agg_handler(text, text_question, numeric_list, string_list):
    word_list = text_question.strip(" ").split(" ")
    txt_len = len(word_list)
    if txt_len == 2:
        return {
            'statusCode': 200,
            'body': json.dumps([text+" "+x for x in numeric_list])
        }
    elif txt_len == 3:
        if word_list[-1] in numeric_list:
            all_columns = numeric_list + string_list
            return {
                'statusCode': 200,
                'body': json.dumps([text_question+" groupby "+x for x in all_columns])
            }
    else:
        return {
            'statusCode': 200,
            'body': json.dumps([text])
        }
