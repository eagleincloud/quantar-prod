import json
from boto3 import client

def lambda_handler(event, context):
    try:
        conn = client('s3')
        dataset = []
        for key in conn.list_objects(Bucket='quantar-manifest', Prefix='qs-poc-dataset/')['Contents']:
            print(key['Key'].split('qs-poc-dataset/'))
            if len(key['Key'].split('qs-poc-dataset/')[1])>1:
                dataset.append(key['Key'].split('qs-poc-dataset/')[1])
        #raise Exception("Dummy")
        return {
            'statusCode': 200,
            'dataset_list': dataset
        }
    except Exception as e:
        print("Error Message: "+str(e))
        return {
            'statusCode': 400,
            'dataset_list': []
        }
