import json
import boto3


def lambda_handler(event, context):
    client = boto3.client('cognito-idp')
    
    try:
        response = client.change_password(
        PreviousPassword=event['previous_password'],
        ProposedPassword=event['proposed_password'],
        AccessToken=event['access_token']
        )
        
        return {
            'statusCode': 200,
            'body': 'Password Changed Successfully'
        }
    except Exception as e:
        print("Error: ",str(e))
        return {
            'statusCode': 400,
            'error': str(e)
        }
