import json
import boto3
import pymysql
import pandas as pd

def get_user_role(UID):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """SELECT URID as user_role 
                   FROM quantar_user_management.quantar_user WHERE UID = '{}';""".format(UID)
        cur.execute(query)
        records = cur.fetchone()[0]
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def insert_user_details(Username, new_user_id, TID, name, email, UID, user_role):
    query = """INSERT INTO quantar_user_management.quantar_user
                (Username, UID, TID, FirstName, EmailID, UserAddedByID, UserReferalCode, LastUpdateTimestamp, team_account_status, individual_account_status, team_account_exist, individual_account_exist, URID)
                VALUES(%s, %s, %s, %s, %s , %s, %s , now(), 1, 0, 1, 0, %s);"""
    response = run_insert_update_query(
        query, (Username, new_user_id, TID, name, email, UID, UID, user_role))
    return response


def get_team_id(UID):
    try:
        query = """SELECT Username, UID, TID, FirstName as Name, URID as user_role , EmailID
                   FROM quantar_user_management.quantar_user WHERE team_account_status = 1 and TID in 
                   (select TID from quantar_user_management.quantar_user where UID = %s ) ORDER BY LastUpdateTimestamp DESC;"""
        data = run_select_query(query, UID)
        return data
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')

def check_team_member_count(sub):
    query = "select qu.TID from quantar_user qu where qu.UID like '%{}%';".format(
            sub)
    #print(query)
    data = run_select_query(query, None)
    print(data)
    # If Team is available
    if data[0][0]:
        query = """select qpm.teamMemberCount from quantar_package_mgmt qpm 
                    join 
                    (select qph.PackageID 
                    from quantar_payment_history qph 
                    where qph.UID in (select UID from quantar_user where TID = '{}') 
                    and qph.PaymentStatus = 'Success' order by LastUpdateTimestamp Desc limit 1) pid on qpm.PacakageID = pid.PackageID;""".format(data[0][0])
        latest_pack_team_Member_count = 0
        if len(run_select_query(query, None)):
            latest_pack_team_Member_count = run_select_query(query, None)[0][0]

        query = """select count(*) as team_member_no from quantar_user where TID = '{}';""".format(data[0][0])
        created_teammember_count = run_select_query(query, None)[0][0]
        print(created_teammember_count)

        if latest_pack_team_Member_count == 0:
            raise Exception('Purchase a Plan.')

        if latest_pack_team_Member_count <= created_teammember_count:
            raise Exception('Reached the plan team member count limit.') 
    else: #For individual account
        raise Exception('Purchase Team Plan.')


def lambda_handler(event, context):
    try:
        UID = event['sub']
        role = get_user_role(UID)
        print(role)
        if role == "Team User":
            return {
                'statusCode': 400,
                'body': 'User does not have specefic Permission'
            }
        
        TID = event['TID']
        email = event['email']
        name = event['name']
        username = event['username']
        user_role = event['user_role']
        print(event)
        print(TID)
        
        if TID is not None and user_role == "Access level":
            user_role = "Team User"
        elif user_role == "Access level":
            user_role = "Individual User"
        
        #temporary_password = event['tempPwd']

        userAttributes = [{"Name": "email", "Value": email}, {
            "Name": "email_verified", "Value": "false"}, {"Name": "name", "Value": name}, {"Name": "custom:Role", "Value": user_role}]

        user_pool_id = "eu-west-2_8ne74JB2A"
        aws_client = boto3.client('cognito-idp')
        response = aws_client.admin_create_user(UserPoolId=user_pool_id,
                                                Username=username, UserAttributes=userAttributes, DesiredDeliveryMediums=['EMAIL'])
        print("response=", response)

        attributes = response['User']['Attributes']
        Username = response['User']['Username']
        for att in attributes:
            if att['Name'] == 'sub':
                new_user_id = att['Value']

        insert_user_details(Username, new_user_id, TID, name, email, UID, user_role)
        
        data = get_team_id(UID)
        df = pd.DataFrame(
            data, columns=['Username', 'UID', 'TID', 'Name', 'User_Role', 'EmailID'])

        return {
            'statusCode': 200,
            'message': 'User added successfully.',
            'body': df.to_dict('records')
        }

    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body': 'Failure: '+str(e) 
        }