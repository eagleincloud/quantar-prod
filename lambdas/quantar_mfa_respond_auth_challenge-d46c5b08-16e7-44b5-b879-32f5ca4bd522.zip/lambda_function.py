import boto3
import pandas as pd


client_id = "2uhegs5q628bk5q3rcop20jm4j"


def lambda_handler(event, context):
    cognito_client = boto3.client('cognito-idp')
    """Respond To Auth Challenge
    
    """
    print(event, "-------Start------------")
    challenge = event.get('ChallengeName')
    username = event.get('username')
    session = event.get('Session')
    answer = event.get('mfa_code')
    try:
        response = cognito_client.respond_to_auth_challenge(
            ClientId=client_id,
            ChallengeName=challenge,
            Session=session,
            ChallengeResponses={
                'USERNAME': username,
                'ANSWER': answer
            },
        )
        
        cognito_user_att_list = cognito_client.admin_get_user(UserPoolId='eu-west-2_8ne74JB2A', Username=username)['UserAttributes']
        
        dcty = pd.DataFrame(cognito_user_att_list).set_index('Name')['Value'].to_dict()
        dcty['userName'] = username
        print(dcty)
        response['UserAttributes'] = dcty
        return {'statusCode': 200, 'body': response}
    except Exception as e:
        print(str(e))
        return {'statusCode': 400, 'body': 'Error in authorization process. Message {}.'.format(str(e))}
