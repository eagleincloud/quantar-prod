import pymysql
import uuid
import boto3
from datetime import datetime, timedelta

def get_user_role(UID):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """SELECT URID as user_role 
                   FROM quantar_user_management.quantar_user WHERE UID = '{}';""".format(UID)
        cur.execute(query)
        records = cur.fetchone()[0]
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_insert_update_query(query, values):
    try:
        print("Values:",values)
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        
def delete_card_details(user_id,card_number):
    try:
        query = """Delete FROM quantar_user_management.quantar_payment_method where UserID = %s and CardNumber = %s;"""
        return run_insert_update_query(query, (user_id,card_number,))
    except Exception as e:
        print(str(e))
        return False
        
def lambda_handler(event, context):
    try:
        print(event)
        UID = event['sub']  # post method
        role = get_user_role(UID)
        print(role)
        if role == "TeamAdmin" or role == "TeamUser":
            return {
                'statusCode': 400,
                'body': 'User does not have specefic Permission'
            }
            
        user_id = event['sub']
        card_number = int(event['CardNumber'])
        print(user_id)
        response = delete_card_details(user_id,card_number)
        return {
            'statusCode': 200,
            'body': 'Payment Method deleted successfully.'
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': str(e)
        }
