import json
import pymysql
from datetime import datetime, timedelta
import pandas as pd
import boto3

def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def check_dataset_quantity(sub):
    query = "select qu.TID from quantar_user qu where qu.UID like '%{}%';".format(
            sub)
    #print(query)
    data = run_select_query(query)
    print(data)
    # If Team is available
    if data[0][0]:
        query = """select qpm.dataSetCount from quantar_package_mgmt qpm 
                    join 
                    (select qph.PackageID 
                    from quantar_payment_history qph 
                    where qph.UID in (select UID from quantar_user where TID = '{}') 
                    and qph.PaymentStatus = 'Success' order by LastUpdateTimestamp Desc limit 1) pid on qpm.PacakageID = pid.PackageID;""".format(data[0][0])
        latest_pack_dataset_count = 0
        if len(run_select_query(query)):
            latest_pack_dataset_count = run_select_query(query)[0][0]

        query = """select count(TID)  from quantar_user_dataset qud where TID = '{}';""".format(data[0][0])
        uploaded_dataset_count = run_select_query(query)[0][0]
        print(uploaded_dataset_count)

        if latest_pack_dataset_count == 0:
            raise Exception('Purchase a Plan.')

        if uploaded_dataset_count == latest_pack_dataset_count:
            raise Exception('Reached the plan dataset limit.') 
    else: #For individual account
        query = """select qpm.dataSetCount from quantar_package_mgmt qpm 
                    join 
                    (select qph.PackageID 
                    from quantar_payment_history qph 
                    where qph.UID = '{}'
                    and qph.PaymentStatus = 'Success' order by LastUpdateTimestamp Desc limit 1) pid on qpm.PacakageID = pid.PackageID;""".format(sub)
        latest_pack_dataset_count = 0
        if len(run_select_query(query)):
            latest_pack_dataset_count = run_select_query(query)[0][0]

        query = """select count(UID)  from quantar_user_dataset qud where UID = '{}';""".format(sub)
        uploaded_dataset_count = run_select_query(query)[0][0]
        print(uploaded_dataset_count)

        if latest_pack_dataset_count == 0:
            raise Exception('Purchase a Plan.')

        if uploaded_dataset_count == latest_pack_dataset_count:
            raise Exception('Reached the plan dataset limit.')

def run_insert_update_delete_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def insert_file_in_database(UID, TID, DatasetName, DatasetS3Path, ConnectorName, UCONID, dataset_size):
    query = """INSERT INTO quantar_user_management.quantar_user_dataset
                (UID, TID, DatasetName, DatasetS3Path, ConnectorName, UCONID, dataset_size, Status, LastUpdateTimestamp)
                VALUES(%s, %s, %s, %s, %s, %s, %s, 'Active', now());
                """
    run_insert_update_delete_query(
        query, (UID, TID, DatasetName, DatasetS3Path, ConnectorName, UCONID, dataset_size))


def lambda_handler(event, context):
    try:
        check_dataset_quantity(event["ID"])
    except Exception as e:
        return {
            'statusCode': 400,
            'body': str(e)
        }

    conn = pymysql.connect(
        host=event["Host"],
        user=event["Master_username"],
        password=event["Master_password"],
        db=event["DB_name"]
    )
    table_name = event["Table_Name"].replace(" ", "")
    query = f"Select * from {table_name} limit 10000;"
    try:
        df = pd.read_sql(query, conn)
        #print(df)

        path = "s3://quantar-production-bucket/" + \
            event["ID"]+"/"+table_name+"/"+table_name+".csv"
        df.to_csv(path, index=False)

    except Exception as e:
        print(str(e))
        return {
            'statusCode': 200,
            'body': 'Error: '+str(e)
        }
    finally:
        conn.close()

    try:
        key = event["ID"]+"/"+table_name+"/"+table_name+".csv"
        s3 = boto3.resource('s3')
        object = s3.Object('quantar-production-bucket', key)
        file_size = object.content_length  # size in bytes

        UID = event["ID"]
        TID = None
        DatasetName = table_name+".csv"
        DatasetS3Path = path
        ConnectorName = 'MySQL'
        UCONID = None
        dataset_size = str(file_size)+'bytes'

        insert_file_in_database(
            UID, TID, DatasetName, DatasetS3Path, ConnectorName, UCONID, dataset_size)

        return {
            'statusCode': 200,
            'body': 'Success'
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 200,
            'body': 'Error: '+str(e)
        }
