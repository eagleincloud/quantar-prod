import json
import boto3
import pandas as pd
import ast
import io
import pymysql

def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        
def check_team(sub):
    query='''SELECT TID FROM quantar_user WHERE UID=%s''';
    data = run_select_query(query, (sub,))
    print(data)
    return data
    
def get_file(sub,file_name):
    is_team=check_team(sub)
    
    if is_team[0][0] is not None:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IN 
        (SELECT TID FROM quantar_user WHERE UID=%s)''';
        data=run_select_query(query, (file_name,sub,))
        return data[0][0]
        
    else:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IS NULL''';
        data=run_select_query(query, (file_name,))
        return data[0][0]
        


def s3_client(sub, filename):
    try:
        bucket_name = 'quantar-production-bucket'
        folder_name=filename.split('.')[0]
        
        # object_key = sub+'/'+folder_name+'/'+filename
        file_path = get_file(sub,filename)
        object_key="/".join(file_path.split('/')[3:])
        print(object_key)
    
        s3c = boto3.client('s3')
    
        obj = s3c.get_object(Bucket=bucket_name, Key=object_key)
    
        df = pd.read_csv(io.BytesIO(obj['Body'].read()), encoding='latin-1')
        
        print(df.head(5).to_dict('records'))
        return {
            "statusCode": 200,
            "fileData": df.head(5).to_dict('records')
        }
    except Exception as e:
        print(str(e))
        return {
            "statusCode": 400,
            "Error": "Error in parsing"
        }       

def lambda_handler(event, context):
    try:
        sub = event["params"]["querystring"]["sub"]
        file_name = event["params"]["querystring"]["file_name"]
        return s3_client(sub, file_name)
    except Exception as e:
        print(str(e))
        return{
            "statuscode": 400,
            "fileData": {},
            "Error: ":json.dumps(str(e))
        }

