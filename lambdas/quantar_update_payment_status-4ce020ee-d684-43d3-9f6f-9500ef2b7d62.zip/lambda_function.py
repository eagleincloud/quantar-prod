import json
import pymysql
import uuid
import random
from datetime import datetime, timedelta
import stripe
import boto3


endpoint_secret = 'whsec_LEWGWr6lYSYnuTUaSiyhIPqPL3qQTKL9'

def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def get_payment_intent_details(payment_intent_id):
    query = """SELECT id, sub, request_time, Status, planid, payment_intent_id 
               FROM quantar_user_management.quantar_payment_intent_genration_log where payment_intent_id = %s;"""
    data = run_select_query(query, (payment_intent_id,))
    return data

def update_team(UID,TID):
    query="""UPDATE quantar_user_management.quantar_user 
    SET TID=%s, URID="Team Manager", team_account_status=1, individual_account_status=0, 
    team_account_exist=1, individual_account_exist=0 where UID=%s;"""
    
    response = run_insert_update_query(query, (TID, UID))
    
    query2="""UPDATE quantar_user_management.quantar_user_dataset SET TID=%s WHERE UID=%s;"""
    
    response2=run_insert_update_query(query2,(TID, ))
    
    
    

def process_user_Payment(event):
    InvoiceID = uuid.uuid4()
    transactionID = event['transactionID']
    UID = event['sub']
    payment_mode = event['PaymentMode']
    payment_status = event['PaymentStatus']
    packageId = event['PackageID']
    lastUpdateTimestamp = event['LastUpdateTimestamp']
    
    #Check if user is present in some team or not. If not then add it into random team.
    is_team=check_team(UID)
    if is_team[0][0] is None and packageId!="Individual":
        value=random.randint(0000,9999)
        TID="team-"+str(value)
        update_team(UID,TID)
        
        

    package_details_query = """SELECT * FROM quantar_user_management.quantar_package_mgmt where PackageName = %s;"""

    package_details = run_select_query(package_details_query, (packageId,))

    if package_details:
        PackageName = package_details[0][0]
        PacakageID = package_details[0][1]
        packageDays = package_details[0][2]
        teamMemberCount = package_details[0][3]
        dataSetCount = package_details[0][4]
    else:
        raise Exception("Package Not Found")

    payment_history_query = """ INSERT INTO quantar_user_management.quantar_payment_history
        (InvoiceID, UID, PaymentMode, PaymentStatus, PackageID, LastUpdateTimestamp, transactionID)
        VALUES(%s, %s, %s, %s, %s, %s, %s);"""

    response = run_insert_update_query(payment_history_query, (InvoiceID, UID,
                                                               payment_mode, payment_status, packageId, lastUpdateTimestamp, transactionID))

    if not response:
        raise Exception("Error in payment history insert")

    # SubscriptionEndDate = datetime.strptime(
    #     lastUpdateTimestamp, '%y-%m-%d %H:%M:%S') + timedelta(days=packageDays)
    
    SubscriptionEndDate = lastUpdateTimestamp + timedelta(days=packageDays)

    update_user_details = """UPDATE quantar_user_management.quantar_user SET individual_account_status=1 , SubscriptionEndDate = %s where UID=%s;"""

    response = run_insert_update_query(
        update_user_details, (SubscriptionEndDate, UID))

    if not response:
        raise Exception("Error in user management insert")
    
        
    #Create the particular user to quicksight.    
    client=boto3.client('lambda')
    inputParams = {
        "sub"   : UID }
 
    response = client.invoke(
        FunctionName = 'arn:aws:lambda:eu-west-2:625302196318:function:quantar_create_quicksight_user',
        InvocationType = 'RequestResponse',
        Payload = json.dumps(inputParams)
    )
 
    responseFromChild = json.load(response['Payload'])
    print("QuickSight Lambda: ",responseFromChild)
        
    return InvoiceID


def webhook(webhook_event):
    payload = webhook_event
    sig_header = payload['headers']['Stripe-Signature']
    event = None

    try:
        event = stripe.Webhook.construct_event(
            payload['body'], sig_header, endpoint_secret
        )
    except ValueError as e:
        # invalid payload
        print(str(e))
        return "Invalid payload", 400
    except stripe.error.SignatureVerificationError as e:
        # invalid signature
        print(str(e))
        return "Invalid signature", 400
    except Exception as e:
        # invalid payload
        print(str(e))
        return "Error: str(e)", 400    

    event_dict = event.to_dict()
    if event_dict['type'] == "payment_intent.succeeded":
        intent = event_dict['data']['object']
        print("Succeeded: ", intent['id'])
        payment_intent_details = get_payment_intent_details(intent['id'])

        success_payload = {}
        success_payload['transactionID'] = intent['id']
        success_payload['sub'] = payment_intent_details[0][1]
        success_payload['PaymentMode']='CARD'
        success_payload['PaymentStatus']='Success'
        success_payload['PackageID']=payment_intent_details[0][4]
        success_payload['LastUpdateTimestamp']=payment_intent_details[0][2]

        print(success_payload)

        process_user_Payment(success_payload)

    elif event_dict['type'] == "payment_intent.payment_failed":
        intent = event_dict['data']['object']
        error_message = intent['last_payment_error']['message'] if intent.get('last_payment_error') else None
        print("Failed: ", intent['id'], error_message)
        # Notify the customer that payment failed

    return "OK", 200

def check_team(sub):
    query='''SELECT TID FROM quantar_user WHERE UID=%s''';
    data = run_select_query(query, (sub,))
    print(data)
    return data


def lambda_handler(event, context):
    try:  
        print(event)
        message, statusCode = webhook(event)
        print(message, statusCode)
        return {
            'statusCode': statusCode,
            'body': message
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body': "Error message: "+str(e)
        }