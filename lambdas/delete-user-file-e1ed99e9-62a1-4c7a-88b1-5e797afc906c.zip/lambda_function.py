import boto3
import pymysql
import pandas as pd


def run_insert_update_delete_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def delete_file_from_database(id, file_name, dataset_name):
    try:
        query = """DELETE FROM quantar_user_management.quantar_user_dataset WHERE datasetname = %s and uid = %s;"""
        run_insert_update_delete_query(query, (file_name, id))
        
        client = boto3.client('quicksight')
        response = client.delete_data_set(
        AwsAccountId='625302196318',
        DataSetId=dataset_name
    )
    
    except Exception as e:
        print(str(e))
        


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def get_file_details(id, is_team):
    print("Inside File Details")
    try:
        query = """SELECT qud.DID, qud.DatasetName, qud.ConnectorName, qud.dataset_size, qud.LastUpdateTimestamp, qu.Username
        FROM quantar_user_management.quantar_user_dataset qud 
        INNER JOIN (
		 SELECT qud.UID, qud.TID, qud.DatasetName, MAX(LastUpdateTimestamp) AS LastUpdateTimestamp
		 FROM quantar_user_management.quantar_user_dataset qud
		 GROUP BY qud.UID, qud.TID, qud.DatasetName
		 ) AS a
		 ON a.UID = qud.UID AND a.LastUpdateTimestamp = qud.LastUpdateTimestamp
        LEFT JOIN quantar_user_management.quantar_user qu
        ON qu.UID=qud.UID
        WHERE qud.UID=%s AND qud.TID IS NULL;"""
	    
        if is_team.lower() != 'false':
            query = """SELECT qud.DID, qud.DatasetName, qud.ConnectorName, qud.dataset_size, qud.LastUpdateTimestamp, qu.Username
         FROM quantar_user_management.quantar_user_dataset qud 
		 INNER JOIN (
		 SELECT qud.UID, qud.TID, qud.DatasetName, MAX(qud.LastUpdateTimestamp) AS LastUpdateTimestamp
		 FROM quantar_user_management.quantar_user_dataset qud
		 GROUP BY qud.UID, qud.TID, qud.DatasetName
		 ) AS a
		 ON a.UID = qud.UID AND a.LastUpdateTimestamp = qud.LastUpdateTimestamp
		 LEFT JOIN quantar_user_management.quantar_user qu ON qu.UID=qud.UID 
		 WHERE qud.TID=(SELECT TID FROM quantar_user_management.quantar_user qu WHERE
	        qu.UID= %s AND qu.TID IS NOT NULL);"""
	        
        data = run_select_query(query, (id,))
        df = pd.DataFrame(data, columns=[
                          'DatasetID',	'DatasetName',	'ConnectorName', 'dataset_size', 'LastUpdateTimestamp',	'Username'])
        
        print(df)                  
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        raise Exception('Database Error: '+str(e))


def get_managed_srvc_dtls():
    try:
        print("Inside Get Managed Service detail")
        query = """SELECT * FROM quantar_user_management.quantar_managed_service;"""
        data = run_select_query(query,None)
        df = pd.DataFrame(data, columns=['MSID', 'MSName'])
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')

def get_quicksight_dataset_name(id,file_name):
    try:
        query='''SELECT QuickSight_Dataset_Name FROM `quantar_user_dataset` WHERE UID="{}" AND 
        DatasetName= '{}'; '''.format(id,file_name)
        data=run_select_query(query,None)
        
        return data[0][0]
        
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')

def delete_glue_table(id,file_name_with_csv):
    
    try:
        query="""SELECT Username FROM `quantar_user` WHERE UID="{}"; """.format(id)
        value=run_select_query(query,None)
        db_name=value[0][0]
        client = boto3.client('glue')
        
        file_name=file_name_with_csv.split('.')[0]
        response = client.delete_table(
        CatalogId="625302196318",
        DatabaseName=db_name,
        Name=file_name
    )
    
    except Exception as e:
        print(str(e))
        raise Exception(e)

def lambda_handler(event, context):
    print(event)

    try:
        file_name = event['file_name']
        id = event['sub']
        is_team = str(event['is_team'])
        
        dataset_name=get_quicksight_dataset_name(id,file_name)

        delete_file_from_database(id, file_name,dataset_name)
        
        delete_glue_table(id,file_name)
        
        folder_name=file_name.split('.')[0]
        key = id + '/' + folder_name + '/' + file_name
        client = boto3.client('s3')
        client.delete_object(Bucket='quantar-production-bucket', Key=key)
        
        print(id, is_team)
        file_names = get_file_details(id, is_team)
        managed_service =get_managed_srvc_dtls()
        return {
            'statusCode': 200,
            'data': file_names,
            'managed_service': managed_service
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body': str(e)
        }
