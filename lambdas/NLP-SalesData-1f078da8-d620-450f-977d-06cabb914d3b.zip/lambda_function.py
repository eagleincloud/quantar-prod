import json
import boto3

import pandas as pd

import io

import os


def lambda_handler(event, context):
    
    bucket_name = 'quantar-production-bucket'
    object_key = 'd195b954-5ff5-41aa-b7cd-f4c338d82cc4/sales_data_sample.csv'
    #'d195b954-5ff5-41aa-b7cd-f4c338d82cc4/new_dataset.csv'
    
    s3c = boto3.client('s3')

    obj = s3c.get_object(Bucket= bucket_name , Key = object_key)

    df = pd.read_csv(io.BytesIO(obj['Body'].read()),encoding='latin-1')
    #data = pd.read_csv(io.BytesIO(obj['Body'].read()),encoding='latin-1')
    data = df
    #df = pd.read_csv("sales_data_sample.csv",encoding='latin-1')
    print(data)
    
    print(os.environ['bucketName'])
    print(os.environ['saveMessage'])
    print(os.environ['formatMessage'])

 
 