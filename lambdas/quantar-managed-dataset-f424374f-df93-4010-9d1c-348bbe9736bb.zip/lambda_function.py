import boto3
import pymysql
import uuid
import os
from datetime import datetime

dest_bucket = os.environ["destination_bucket"]

def get_user_role(UID):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """SELECT URID as user_role 
                   FROM quantar_user_management.quantar_user WHERE UID = '{}';""".format(UID)
        cur.execute(query)
        records = cur.fetchone()[0]
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def insert_managed_dataset_details(MSDID, UID, TID, MSID, DID):
    if TID:
        query = """INSERT INTO quantar_user_management.quantar_managed_service_datasets
                (MSDID, UID, TID, MSID, DID, Status, LastUpdateTimestamp)
                    VALUES(%s, %s, %s, %s, %s , 'Active', now());"""
        run_insert_update_query(query, (MSDID, UID, TID, MSID, DID))            
    else:
        query = """INSERT INTO quantar_user_management.quantar_managed_service_datasets
                (MSDID, UID, MSID, DID, Status, LastUpdateTimestamp)
                    VALUES(%s, %s, %s, %s , 'Active', now());"""
        run_insert_update_query(query, (MSDID, UID, MSID, DID))


def send_notification(dataset_name, service_name):
    print("WOw 0",service_name)
    ses=boto3.client('ses')
    email_subject = 'Quantar : New {} request.'.format(service_name)
    body="""
    Hello,
    
    Your dataset {} has been added for Procressing.
    You can check in quantar-managed-bucket in S3 under today's date.
    
    Thanks
    """.format(dataset_name)
    
    ses.send_email(
		Source="tech@quantar.io",
		Destination={
			'ToAddresses':[
				"quantar@shaip.com","idrismhowwala@gmail.com",]
		},
		Message={
			'Subject':{
				'Data':email_subject,
				'Charset': 'UTF-8'
			},
			'Body':{
				'Text':{
					'Data':body,
					'Charset': 'UTF-8'
				}
			}
		}
	)
    
    print("E-mail sent Successfully")



def copy_file_to_input_bucket(UID, dataset_name):
    dataset_name2=dataset_name+"_"+UID
    print(dataset_name2)
    s3 = boto3.resource('s3')
    folder_name=dataset_name.split('.')[0]
    key=UID+'/'+folder_name+'/'+dataset_name
    print("Key: ",key)
    copy_source = {
        'Bucket': 'quantar-production-bucket',
        'Key': key
    }

    otherkey = datetime.today().strftime('%Y%m%d')+"/"+dataset_name2
    s3.meta.client.copy(copy_source, dest_bucket, otherkey)
    
    return dataset_name2


def lambda_handler(event, context):
    try:
        print(event)
        UID = event['sub']  # get method
        role = get_user_role(UID)
        print(role)
        if role == "TeamAdmin" or role == "TeamUse":
            return {
                'statusCode': 400,
                'body': 'User does not have specefic Permission'
            }
        sub = event["sub"]
        dataset_id = event["dataset_id"]
        dataset_name = event["dataset_name"]
        managed_srvc_id = event["managed_srvc_id"]
        team_id = None
        if "team_id" in event:
            team_id = event["team_id"]
        MSDID = uuid.uuid4()
        insert_managed_dataset_details(
            MSDID, sub, team_id, managed_srvc_id, dataset_id)

        new_dataset_name=copy_file_to_input_bucket(sub, dataset_name)
        
        if managed_srvc_id == "1":
            service_name = 'Dataset Cleaning'
        else:
            service_name = 'Dataset Enrichment'
        
        send_notification(new_dataset_name, service_name)

        # TODO implement
        return {
            'statusCode': 200,
            'body': 'Process Started'
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'Error': str(e)
        }
