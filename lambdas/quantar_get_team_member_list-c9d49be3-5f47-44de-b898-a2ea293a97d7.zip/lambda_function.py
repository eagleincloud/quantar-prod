import pymysql
import pandas as pd


def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def get_team_id(UID):
    try:
        query = """SELECT Username, UID, TID, FirstName as Name, URID as user_role , EmailID
                   FROM quantar_user_management.quantar_user WHERE team_account_status = 1 and TID in 
                   (select TID from quantar_user_management.quantar_user where UID = '{}' ) ORDER BY LastUpdateTimestamp DESC;""".format(UID)
        data = run_select_query(query)
        return data
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')


def lambda_handler(event, context):
    try:
        UID = event['params']['querystring']['sub']
        data = get_team_id(UID)
        df = pd.DataFrame(
            data, columns=['Username', 'UID', 'TID', 'Name', 'User_Role', 'EmailID'])
        return {
            'statusCode': 200,
            'body': df.to_dict('records')
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body': 'Error in the fetching team members. Message: {0}'.format(str(e))
        }
