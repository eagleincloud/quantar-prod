import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta
import pandas as pd


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def list_packages():
    try:
        query = """SELECT * FROM quantar_user_management.quantar_package_mgmt;"""
        data = run_select_query(query, None)
        df = pd.DataFrame(data, columns=[
                          'PackageName', 'PacakageID', 'packageDays', 'teamMemberCount', 'dataSetCount', 'Cost'])
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        return {}


def get_package_details(package_id):
    try:
        query = """SELECT * FROM quantar_user_management.quantar_package_mgmt where PacakageID = %s;"""
        data = run_select_query(query, (package_id,))
        df = pd.DataFrame(data, columns=[
                          'PackageName', 'PacakageID', 'packageDays', 'teamMemberCount', 'dataSetCount', 'Cost'])
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        return {}


def delete_package_details(package_id):
    try:
        query = """Delete FROM quantar_user_management.quantar_package_mgmt where PacakageID = %s;"""
        return run_insert_update_query(query, (package_id,))
    except Exception as e:
        print(str(e))
        return False


def create_package(package_id, package_name, package_days, team_member_count, data_set_count, cost):
    try:
        query = """INSERT INTO quantar_user_management.quantar_package_mgmt
                    (PackageName, PacakageID, packageDays, teamMemberCount, dataSetCount, Cost)
                    VALUES(%s, %s, %s, %s, %s, %s);"""
        return run_insert_update_query(query, (package_name, package_id, package_days, team_member_count, data_set_count, cost))
    except Exception as e:
        print(str(e))
        return False


def update_package(package_id, update_attributes, attribute_values):
    query_part1 = "Update quantar_user_management.quantar_package_mgmt set "
    query_part2 = ' , '.join(update_attributes)
    query_part3 = " where PacakageID = %s;"
    query = query_part1 + query_part2 + query_part3
    attribute_values.append(package_id)
    return run_insert_update_query(query, tuple(attribute_values))


def lambda_handler(event, context):
    try:
        operation_type = event['operation_type']
        if operation_type == 'list':
            data = list_packages()
            return {
                'statusCode': 200,
                'data': data
            }
        elif operation_type == 'get':
            package_id = event['package_id']
            data = get_package_details(package_id)
            return {
                'statusCode': 200,
                'data': data
            }
        elif operation_type == 'delete':
            package_id = event['package_id']
            response = delete_package_details(package_id)
            return {
                'statusCode': 200,
                'isPackageDeleted': response
            }
        elif operation_type == 'insert':
            package_id = event['package_id']
            package_name = event['PackageName']
            package_days = int(event['packageDays'])
            team_member_count = int(event['teamMemberCount'])
            data_set_count = int(event['dataSetCount'])
            cost = float(event['Cost'])
            response = create_package(
                package_id, package_name, package_days, team_member_count, data_set_count, cost)
            return {
                'statusCode': 200,
                'isPackageAdded': response
            }
        elif operation_type == 'update':
            package_id = event['package_id']
            update_attributes = []
            attribute_values = []
            if 'PackageName' in event:
                update_attributes.append('PackageName = %s')
                attribute_values.append(event['PackageName'])

            if 'packageDays' in event:
                update_attributes.append('packageDays = %s')
                attribute_values.append(int(event['packageDays']))

            if 'teamMemberCount' in event:
                update_attributes.append('teamMemberCount = %s')
                attribute_values.append(int(event['teamMemberCount']))

            if 'dataSetCount' in event:
                update_attributes.append('dataSetCount = %s')
                attribute_values.append(int(event['dataSetCount']))

            if 'Cost' in event:
                update_attributes.append('Cost = %s')
                attribute_values.append(float(event['Cost']))

            if update_attributes:
                response = update_package(
                    package_id, update_attributes, attribute_values)
                return {
                    'statusCode': 200,
                    'isPackageUpdated': response
                }
            else:
                return {
                    'statusCode': 200,
                    'isPackageAdded': False
                }
        else:
            raise Exception('Wrong Operation')
    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
