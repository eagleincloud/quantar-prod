import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta
import pandas as pd



def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def list_packages(packageID, Priority):
    try:
        
        def plan(row):
            print("Value: ",row.Priority)
            if row.Priority > Priority:
                return "Upgrade"
            elif row.Priority < Priority:
                return "Downgrade"
            else:
                return "Current"
                
        query = """SELECT * FROM quantar_user_management.quantar_package_mgmt;"""
        data = run_select_query(query, None)
        df = pd.DataFrame(data, columns=['PackageName', 'PacakageID', 'packageDays', 'teamMemberCount', 'dataSetCount', 'Cost', 'Description', 'color_code', 'Priority'])
        df['Cost'] = '$'+ df['Cost'].astype(str)                  
        print(packageID)
        df['is_selected_package'] = df.apply(lambda row: True if row.PacakageID == packageID else False , axis = 1)
        df['Plan_Status'] = df.apply(lambda row: plan(row), axis = 1)
        if packageID=="Individual":
            return df.to_dict('records')
        else:
            df = df[df.PackageName != "Individual"]
            return df.to_dict('records')
        
        
    except Exception as e:
        raise e

def get_last_purchased_package(id):
    try:
        query = """SELECT PackageID FROM quantar_user_management.quantar_payment_history where UID = '{}' Order By LastUpdateTimestamp DESC LIMIT 1;""".format(id)
        data = run_select_query(query,None)
        print("PackageID: ",data)
        if data:
            return data[0][0]
        else:
            return None
        
    except Exception as e:
        raise e
        
def get_priority(id):
    try:
        query = """SELECT Priority FROM quantar_user_management.quantar_package_mgmt where PackageName = %s;"""
        data = run_select_query(query,(id,))
        return data[0][0]
    except Exception as e:
        raise e
    
def list_package_first_user():
    try:
        query = """SELECT * FROM quantar_user_management.quantar_package_mgmt;"""
        data = run_select_query(query, None)
        df = pd.DataFrame(data, columns=['PackageName', 'PacakageID', 'packageDays', 'teamMemberCount', 'dataSetCount', 'Cost', 'Description', 'color_code', 'Priority'])
        return df.to_dict('records')
    except Exception as e:
        raise e
        
def check_team(sub):
    query='''SELECT TID FROM quantar_user WHERE UID=%s''';
    data = run_select_query(query, (sub,))
    print(data)
    return data

def list_package_for_new_user():
    query = """SELECT * FROM quantar_user_management.quantar_package_mgmt;"""
    data = run_select_query(query, None)
    df = pd.DataFrame(data, columns=['PackageName', 'PacakageID', 'packageDays', 'teamMemberCount', 'dataSetCount', 'Cost', 'Description', 'color_code', 'Priority'])
    df['Cost'] = '$'+ df['Cost'].astype(str)                  
    df['is_selected_package'] = df.apply(lambda row: False , axis = 1)
    df['Plan_Status'] = df.apply(lambda row: "Upgrade", axis = 1)
    
    return df.to_dict('records')
    
def lambda_handler(event, context):
    try:
        id = event['params']['querystring']['sub']
        print(id)
        is_team=check_team(id)
        print("Team: ",is_team)
        
        packageID = get_last_purchased_package(id)
        if packageID is None :
            data = list_package_for_new_user()
            
        else:
            getPriority = get_priority(packageID)
            data = list_packages(packageID, getPriority)
        return {
            'statusCode': 200,
            'data': data
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
