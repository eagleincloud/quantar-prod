import pymysql
import boto3


def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        raise Exception("Database Error.")
    finally:
        conn.close()


def check_mfa_status(Username):
    query = """SELECT mfa_status FROM quantar_user_management.quantar_user where Username = '{}';""".format(
        Username)
    data = run_select_query(query)
    mfa_status = data[0][0]
    return mfa_status


def sign_me_in(username):
    """SignIn

    """
    cognito_client = boto3.client('cognito-idp')
    try:
        response = cognito_client.initiate_auth(
            ClientId='2uhegs5q628bk5q3rcop20jm4j',
            AuthFlow='CUSTOM_AUTH',
            AuthParameters={
                'USERNAME': username
            }
        )
    except cognito_client.exceptions.NotAuthorizedException:
        return None, "The username or password is incorrect"
    except Exception as e:
        print(e, '------------------ signin error  ---------------------')
        return None, "Unknown error"
    return response, None


def lambda_handler(event, context):

    username = event['username']
    try:
        mfa_status = check_mfa_status(username)
        print(mfa_status)
        if mfa_status:
            pass
        else:
            return {'statusCode': 400, 'body': 'MFA is not activated.'}
    except Exception as e:
        print(str(e))

    response, error = sign_me_in(username)

    if error:
        return {'statusCode': 400, 'body': error}

    return {'statusCode': 200, 'body': response}
