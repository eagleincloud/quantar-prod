import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
# Request Body
# {
#     'username':"",
#     'email':"",
#     'name':''
# }        
def lambda_handler(event, context):
    try:
        client = boto3.client('cognito-idp')
        
        response = client.admin_get_user( UserPoolId='eu-west-2_8ne74JB2A', Username=event["username"])
        
        attribute_list = response['UserAttributes']
        print(attribute_list)
        for attribute in attribute_list:
            if attribute['Name'] == 'email':
                current_email = attribute['Value']
            if attribute['Name'] == 'name':
                current_name = attribute['Value'] 
        
        update_check = False
        if event["name"] != current_name:
            value=event["name"]
            username=event["username"]
            response = client.admin_update_user_attributes(
            UserPoolId='eu-west-2_8ne74JB2A',
            Username=event["username"],
            UserAttributes=[
                {
                    'Name': 'name',
                    'Value': value
                },
            ])
            update_user_details = """UPDATE quantar_user_management.quantar_user SET FirstName=%s where Username=%s;"""
            response = run_insert_update_query(update_user_details, (value,username,))
            update_check =True
        
        if event["email"] != current_email:
            value=event["email"]
            username=event["username"]
            response = client.admin_update_user_attributes(
            UserPoolId='eu-west-2_8ne74JB2A',
            Username=event["username"],
            UserAttributes=[
                {
                    'Name': 'email',
                    'Value': value
                },
            ])
            update_user_details = """UPDATE quantar_user_management.quantar_user SET EmailID=%s where Username=%s;"""
            response = run_insert_update_query(update_user_details, (value,username,))
            update_check = True
        
        if update_check:
            return {
            'statusCode': 200,
            'body': 'Changes updated successfully.'
        }
        else:
            return {
            'statusCode': 200,
            'body': 'No changes are there.'
        }
    except Exception as e:
        print("Error: " + str(e))
        return {
            'statusCode': 400,
            'body': 'Error in updating the attributes.'
        }
        
