import json
import boto3
from datetime import date
import pymysql

def lambda_handler(event, context):
    try:
        sub=event["sub"]
        fileName=event["fileName"]
        question = event['question']
        mysqlconnect(sub, fileName, question)
        return {
        'statusCode': 200,
        'body': json.dumps('Question Saved')
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps('Error!! could not save the question.')
        }
    

  
def mysqlconnect(sub, fileName, question):
    # To connect MySQL database
    try:
        conn = pymysql.connect(
        host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
        user='quantar_admin', 
        password = "fuSPFRpovgpLpjP8lVBO",
        db='quantar_user_management',
        )
      
        cur = conn.cursor()
          
        # Insert query
        cur.execute("INSERT INTO quantar_user_management.quantar_questions_manager (sub, dataset_name, question, status) VALUES( %s, %s, %s, 'Active');", (sub, fileName, question))
        conn.commit()
    except Exception as e:
        print(str(e))
        raise e
    finally:
        conn.close()