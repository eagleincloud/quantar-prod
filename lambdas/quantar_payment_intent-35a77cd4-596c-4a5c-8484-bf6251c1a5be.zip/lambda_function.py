import stripe
import json
import os
import pymysql
import pandas as pd
from datetime import datetime
import uuid
  


now = datetime.now()

dt_string = now.strftime("%d/%m/%Y %H:%M:%S")


def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def get_package_details(package_id):
    try:
        query = """SELECT PackageName, PacakageID, packageDays, teamMemberCount, dataSetCount, Cost, Priority FROM quantar_user_management.quantar_package_mgmt where PackageName = '{}';""".format(package_id)
        data = run_select_query(query)
        print(data)
        return data
    except Exception as e:
        print(str(e))


def store_payment_intent_requests(sub, Status, planid, payment_intent_id):
    try:
        query = """INSERT INTO quantar_user_management.quantar_payment_intent_genration_log
                    (sub, request_time, Status, planid, payment_intent_id)
                    VALUES(%s,now(), %s, %s, %s);"""
        return run_insert_update_query(query, (sub, Status, planid, payment_intent_id))
    except Exception as e:
        print(str(e))
        return False

def get_user_present_package(sub):
    try:
        query="""SELECT * FROM `quantar_payment_history` WHERE UID='{}' ORDER BY LastUpdateTimestamp DESC LIMIT 1;""".format(sub)
        data = run_select_query(query)
        return data[0][6]
    except Exception as e:
        print(str(e))

def get_user_details(sub):
    query="""SELECT * FROM `quantar_user` WHERE UID='{}';""".format(sub)
    data = run_select_query(query)
    return data
    
def compare_packages(user_details,new_package,present_package):
    if new_package[0][6]<present_package[0][6]:
        print("Downgrade Action")
        team=user_details[0][2]
        
        query="""SELECT COUNT(*) FROM `quantar_user` WHERE TID='{}';""".format(team)
        team_members_count=run_select_query(query)[0][0]
        
        query="""SELECT COUNT(*) FROM `quantar_user_dataset` WHERE TID='{}';""".format(team)
        team_dataset_count=run_select_query(query)[0][0]
        
        print("Team member: "+str(team_members_count),"Team dataset: "+str(team_dataset_count))
        
        if team_members_count>new_package[0][3]:
            raise Exception("Delete Some Team Members Before continuing..")
            
        elif team_dataset_count>new_package[0][4]:
            raise Exception("Delete Some Datasets Before continuing..")
        
        else:
            return True
        
        
    else:
        return True
        
    
def lambda_handler(event, context):
    try:
        # TODO implement
        stripe.api_key = os.environ['stripe_key']
        print(event)
        user_id = event["sub"]
        PacakageID = event["PacakageID"]
        
        user_details=get_user_details(user_id)
        print(user_details)
        package_data = get_package_details(PacakageID)
        
        present_package=get_user_present_package(user_id)
        print("Success: ",present_package)
        if present_package is None:
            pass
        else:
            present_package_data=get_package_details(present_package)
            condition=compare_packages(user_details,package_data,present_package_data)

        amount = int(package_data[0][5]*100)
        print(amount)
        order_id = uuid.uuid4()
        
        data = stripe.PaymentIntent.create(
            amount=amount,
            currency="usd",
            payment_method_types=["card"],
            metadata = {"sub": user_id, "package_id": PacakageID, "order_id": order_id, "date": dt_string}
        )
        payment_intent_id = data["id"]
        store_payment_intent_requests(user_id, "Intent Generated", PacakageID, payment_intent_id)

        return {
            'statusCode': 200,
            'body': data
        }
    except Exception as e:
        print("Error: " + str(e))
        store_payment_intent_requests(
            user_id, "Intent Generated Failed. {}".format(str(e)), PacakageID, "Error")
        return {
            'statusCode': 400,
            'error': str(e)
        }

