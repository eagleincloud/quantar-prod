import stripe
import json
import os
import pymysql
import pandas as pd
from datetime import datetime
import uuid
  


now = datetime.now()

dt_string = now.strftime("%d/%m/%Y %H:%M:%S")


def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def get_package_details(package_id):
    try:
        query = """SELECT PackageName, PacakageID, packageDays, teamMemberCount, dataSetCount, Cost FROM quantar_user_management.quantar_package_mgmt where PackageName = '{}';""".format(package_id)
        data = run_select_query(query)
        df = pd.DataFrame(data, columns=[
                          'PackageName', 'PacakageID', 'packageDays', 'teamMemberCount', 'dataSetCount', 'Cost'])
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        return {}


def store_payment_intent_requests(sub, Status, planid, payment_intent_id):
    try:
        query = """INSERT INTO quantar_user_management.quantar_payment_intent_genration_log
                    (sub, request_time, Status, planid, payment_intent_id)
                    VALUES(%s,now(), %s, %s, %s);"""
        return run_insert_update_query(query, (sub, Status, planid, payment_intent_id))
    except Exception as e:
        print(str(e))
        return False


def lambda_handler(event, context):
    try:
        # TODO implement
        stripe.api_key = os.environ['stripe_key']
        print(event)
        user_id = event["sub"]
        PacakageID = event["PacakageID"]

        package_data = get_package_details(PacakageID)

        print(package_data)
        amount = int(package_data[0]["Cost"]*100)
        order_id = uuid.uuid4()

        data = stripe.PaymentIntent.create(
            amount=amount,
            currency="usd",
            payment_method_types=["card"],
            metadata = {"sub": user_id, "package_id": PacakageID, "order_id": order_id, "date": dt_string}
        )
        payment_intent_id = data["id"]
        store_payment_intent_requests(user_id, "Intent Generated", PacakageID, payment_intent_id)

        return {
            'statusCode': 200,
            'body': data
        }
    except Exception as e:
        print("Error: " + str(e))
        store_payment_intent_requests(
            user_id, "Intent Generated Failed. {}".format(str(e)), PacakageID, "Error")
        return {
            'statusCode': 400,
            'error': "Error in generating payment intent. Message {}.".format(str(e))
        }

