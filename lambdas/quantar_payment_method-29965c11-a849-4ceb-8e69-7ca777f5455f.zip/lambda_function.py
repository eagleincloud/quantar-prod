import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta
import pandas as pd

def get_user_role(UID):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """SELECT URID as user_role 
                   FROM quantar_user_management.quantar_user WHERE UID = '{}';""".format(UID)
        cur.execute(query)
        records = cur.fetchone()[0]
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()



def create_package(user_id, holder_name, card_type, card_number, card_expiry):
    try:
        query = """INSERT INTO quantar_user_management.quantar_payment_method
                    (UserID, HolderName, CardType, CardNumber, CardExpiry)
                    VALUES(%s, %s, %s, %s, %s);"""
        return run_insert_update_query(query, (user_id, holder_name, card_type, card_number, card_expiry))
    except Exception as e:
        print(str(e))
        return False


def lambda_handler(event, context):
    try:
        print(event)
        UID = event['sub']  # post method
        role = get_user_role(UID)
        print(role)
        if role == "TeamAdmin" or role == "TeamUser":
            return {
                'statusCode': 400,
                'body': 'User does not have specefic Permission'
            }
    
        user_id = event['sub']
        holder_name = event['HolderName']
        card_type = event['CardType']
        card_number = int(event['CardNumber'])
        card_expiry = event['CardExpiry']
        response = create_package(
            user_id, holder_name, card_type, card_number, card_expiry)
        return {
            'statusCode': 200,
            'body': 'Payment method details added successfully.'
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': str(e)
        }
