import pandas as pd
import numpy as np
import boto3
import io
import json
import copy
import pymysql

def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def check_team(sub):
    query='''SELECT TID FROM quantar_user WHERE UID=%s''';
    data = run_select_query(query, (sub,))
    print(data)
    return data
    
def get_file(sub,file_name):
    is_team=check_team(sub)
    
    if is_team[0][0] is not None:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IN 
        (SELECT TID FROM quantar_user WHERE UID=%s)''';
        data=run_select_query(query, (file_name,sub,))
        return data[0][0]
        
    else:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IS NULL''';
        data=run_select_query(query, (file_name,))
        return data[0][0]
        
        
def get_dataframe(event):
    try:
        sub = event["sub"]
        file_name = event["file_name"]
        bucket = 'quantar-production-bucket'
        file=file_name.split(".")[0]
        # key = sub+'/'+file+'/'+file_name
        # print(key)
        file_path = get_file(sub,file_name)
        key="/".join(file_path.split('/')[3:])
        print(key)
        
        if file_name.endswith('.csv'):
            s3c = boto3.client('s3')
            obj = s3c.get_object(Bucket=bucket, Key=key)
            df = pd.read_csv(io.BytesIO(obj['Body'].read()), encoding='latin-1')
        else:
            df = None
        return df
    except Exception as e:
        return None

def get_aggregation(df, numeric_list):
    columns = numeric_list
    print("COLUMNS: ",columns)
    if columns:
        new_df = df.loc[:, columns]
        new_df=new_df.agg(['sum', 'max', 'min', 'mean'])
        new_df=new_df.round(2)
        print(new_df)
        return new_df.to_dict()
    else:
        return {}


def get_date_column(df):
    date_list = []
    # print(df.columns)
    new_df = df.apply(lambda col: pd.to_datetime(
        col, errors='ignore') if col.dtypes == object else col, axis=0)
    for col in new_df.columns:
        if new_df[col].dtype == 'datetime64[ns]':
            date_list.append(col)
    return date_list


def get_int_float_column(df):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    numeric_list = []
    for col in df.columns:
        # print(col)
        if df[col].dtype in numerics:
            numeric_list.append(col)
    return numeric_list


def resample_data(df, date_column, numeric_list, resampling_value):
    numeric_list.append(date_column)
    new_df = df.loc[:, numeric_list]
    convert_dict = {date_column: 'datetime64[ns]'
                    } 
    new_df = new_df.astype(convert_dict)
    # strftime('%U')

    new_df = new_df.set_index(date_column)
    weekly_resampled_data = new_df.resample(resampling_value).sum()
    weekly_resampled_data = weekly_resampled_data.dropna(how='all')
    #weekly_resampled_data['int_date'] = weekly_resampled_data.index
    weekly_resampled_data['week_number'] = weekly_resampled_data.index.isocalendar().week
    df = weekly_resampled_data[0::len(weekly_resampled_data)-1 if len(weekly_resampled_data) > 1  else 1]
    return df


def lambda_handler(event, context):
    try:
    
        resampling_value = '5d'
        df = get_dataframe(event)
        if not df.empty:
            date_list = get_date_column(df)
            numeric_list = get_int_float_column(df)
            agg_data ={}
            growth_data = {}
            
            if numeric_list:
                agg_data = get_aggregation(df, numeric_list)
            
            if date_list:
                # get_precentage_change(df, date_list[0], numeric_list, resampling_value)
                new_numeric_list=copy.deepcopy(numeric_list) 
                growth_data=resample_data(df, date_list[0], new_numeric_list, resampling_value)
                #print(growth_dict)
            i = 1
            data_list = []
            for col in numeric_list:
                chart_data = []
                if len(growth_data):
                    chart_data = growth_data[col].tolist()
                data_list.append({"columnName":"col"+str(i), "Name":col, "sum":agg_data[col]["sum"], "max":agg_data[col]["max"], "min":agg_data[col]["min"], "mean":agg_data[col]["mean"], "chart_data":chart_data})
                i = i + 1
                
            print(data_list)
            return {
                "statusCode": 200,
                "data": data_list
            }
                
        else:
            return {
                'statusCode': 400,
                'body': 'File Not Found!!'
            }
    except Exception as e:
        return {
                'statusCode': 400,
                'body': str(e)
            }
