import json
import boto3 
import pymysql

def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def check_team(sub):
    query='''SELECT TID FROM quantar_user WHERE UID=%s''';
    data = run_select_query(query, (sub,))
    print(data)
    return data
    
def get_file(sub,file_name):
    is_team=check_team(sub)
    
    if is_team[0][0] is not None:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IN 
        (SELECT TID FROM quantar_user WHERE UID=%s)''';
        data=run_select_query(query, (file_name,sub,))
        return data[0][0]
        
    else:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IS NULL''';
        data=run_select_query(query, (file_name,))
        return data[0][0]
        
        
        

def lambda_handler(event, context):
    try:
        print(event)
        bucket_name = 'quantar-production-bucket'
        sub = event['params']['querystring']['sub']
        file_name = event["params"]["querystring"]["file_name"]
        #folder_name=file_name.split('.')[0]
        
        file_path = get_file(sub,file_name)
        key_name="/".join(file_path.split('/')[3:])
        print(key_name)
        
        client = boto3.client('s3')
        
        URL = client.generate_presigned_url("get_object", Params={"Bucket": bucket_name, "Key": key_name}, ExpiresIn=300)
        
        #print(URL)
        
        # TODO implement
        return {
            'statusCode': 200,
            'headers':{'Content-Type':'application/json'},
            'file_url': URL,
            'isBase64Encoded': False
        }
    
    except Exception as e:
        return {
            'statusCode': 400,
            'Error':json.dumps(str(e))
        }
