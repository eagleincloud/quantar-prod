import json
import pymysql
import pandas as pd
    
def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def get_mfa_status(id):
    try:
        query = """SELECT mfa_status FROM quantar_user_management.quantar_user where UID = %s;"""
        data = run_select_query(query, (id,))
        df = pd.DataFrame(data, columns=['MFA_status'])
        
        final_value=df["MFA_status"][0]                 
        if final_value == 0:
            return "False"
        else:
            return "True"
    except Exception as e:
        print(str(e))
        raise Exception('Database Error: '+str(e))        

def lambda_handler(event, context):
    try:
        print(event)
        id = event['params']['querystring']['sub']
        print(id)
        status=get_mfa_status(id)
        print("Status:",status)
        return {
            'statusCode': 200,
            'MFA_status':status
        }

    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
