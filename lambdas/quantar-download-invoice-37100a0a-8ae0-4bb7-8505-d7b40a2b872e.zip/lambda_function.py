from datetime import datetime
import boto3
import os
import matplotlib.pyplot as plt
import uuid
from fpdf import FPDF
import pandas as pd
import pymysql


def table_create(df):
    # Creating PLot
    fig, ax = plt.subplots()
    ax.axis('tight')
    ax.axis('off')

    fig.subplots_adjust(top=0.75)
    fig.subplots_adjust(bottom=0.58)

    # Table Creation
    the_table = ax.table(cellText=df.values,
                         colLabels=df.columns, colColours=['#5fa7d4', ]*len(df.columns), colWidths = [1]*len(df.columns))

    plt.savefig('/tmp/the_table.png')
    
    s3 = boto3.client('s3')
    s3.upload_file("/tmp/the_table.png", 'quantar-test-bucket', 'the_table.png')


def pie_create(df):
    try:
        plt.clf()
        data = df.iloc[:, 0].tolist()
        labels = df.iloc[:, 1].tolist()
        plt.pie(data, labels=labels, shadow=True)
        plt.savefig('/tmp/the_pie.png')
    except Exception as e:
        print(str(e))
        plt.clf()
        data = df.iloc[:, 0].tolist()
        labels = df.iloc[:, 1].tolist()
        plt.pie(labels, labels=data, shadow=True)
        plt.savefig('/tmp/the_pie.png')


def save_pdf_to_s3(file_directory, sub, bucket_name):
    filename = str(uuid.uuid4())
    key = file_directory + \
        "/"+str(sub)+"/"+filename+".pdf"
    s3 = boto3.client('s3')
    s3.upload_file("/tmp/pdf_one.pdf", bucket_name,
                   key)
    URL = s3.generate_presigned_url("get_object", Params={
        "Bucket": bucket_name, "Key": key})

    return URL


def save_chart_to_s3(file_directory, sub, bucket_name):
    filename = str(uuid.uuid4())
    key = file_directory + \
        "/"+str(sub)+"/"+filename+".png"
    s3 = boto3.client('s3')
    s3.upload_file("/tmp/the_pie.png", bucket_name,
                   key)
    URL = s3.generate_presigned_url("get_object", Params={
        "Bucket": bucket_name, "Key": key})

    return URL


class PDF(FPDF):
    def __init__(self, query, orientation='P', unit='mm', format='A4', is_pie_chart=False):
        self.query = query
        self.is_pie_chart = is_pie_chart
        super().__init__()

    def header(self):
        # logo
        if self.is_pie_chart:
            self.image('quantar-main-logo.png', 10, 1, 40)
            self.image('/tmp/the_pie.png', -40, 20, 280)
            self.image('/tmp/the_table.png', 22, 120, 160)

            # Font
            self.set_font('times', '', 15)
            # Date
            self.cell(350, 10, str(datetime.today())
                      [:10], border=False, ln=1, align='C')
            # Font
            self.set_font('times', '', 20)
            # Title
            self.cell(188, 20, 'QUANTAR', border=False, ln=1, align='C')

            self.set_font('times', '', 12)

            self.cell(0, 30, self.query, border=False, ln=1, align='C')

            # Line Break
            self.ln(20)

        else:
            self.image('quantar-main-logo.png', 10, 8, 40)
            self.image('/tmp/the_table.png', 22, 50, 160)
            # Font
            self.set_font('times', '', 15)
            # Date
            self.cell(350, 10, str(datetime.today())[
                :10], border=False, ln=1, align='C')
            # Font
            self.set_font('times', '', 20)
            # Title
            self.cell(188, 10, 'QUANTAR', border=False, ln=1, align='C')

            self.set_font('times', '', 12)

            self.cell(0, 30, self.query, border=False, ln=1, align='C')

            # Line Break
            self.ln(20)

    def footer(self):
        # Go to 1.5 cm from bottom
        self.set_y(-15)
        # Select Arial italic 8
        self.set_font('arial', 'B', 8)
        # Print centered page number
        self.cell(0, 10, f'Page {self.page_no()}/{{nb}}', 0, 0, 'C')


def save_and_get_url(df, sub, bucket_name, file_directory, sentence, is_pie_chart):
    table_create(df)
    if is_pie_chart:
        pie_create(df)
    pdf = PDF(sentence, 'P', 'mm', 'Letter', is_pie_chart)
    pdf.alias_nb_pages()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.output('/tmp/pdf_one.pdf')
    PDF_URL = save_pdf_to_s3(file_directory, sub, bucket_name)
    os.remove('/tmp/the_table.png')
    CHART_URL = None
    if is_pie_chart:
        CHART_URL = save_chart_to_s3(file_directory, sub, bucket_name)
        os.remove('/tmp/the_pie.png')
    print('PDF Generated Successfully!')
    return PDF_URL, CHART_URL


def get_invoice_details(invoiceid):
    query = """SELECT * FROM quantar_user_management.quantar_payment_history where InvoiceID = '{}';""".format(invoiceid)
    print(query)
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        df = pd.DataFrame(records, columns=['InvoiceID', 'TID', 'UID', 'URID', 'PaymentMode',
                                            'PaymentStatus', 'PackageID', 'TransactionDate', 'transactionID', 'Amount'])
        return df
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def lambda_handler(event, context):
    try:
        invoiceid = event['params']['querystring']['invoiceid']
        sub = event['params']['querystring']['sub']
        df = get_invoice_details(invoiceid)
        PDF_URL, CHART_URL = save_and_get_url(df, sub, 'quantar-production-bucket',
                                              'invoices', 'Invoice_Details',False)
        return {
            'statusCode': 200,
            'body':'Generating Invoice.', 
            'pdf_url': PDF_URL
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body':'Error in generating invoice.', 
            'pdf_url': None
        }