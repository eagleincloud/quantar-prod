import botocore
import boto3
import urllib
import json
import sys
import os
import base64
import pymysql
sys.path.append('/opt/PyRqst/')
#import requests


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def get_userName(sub):
    query='''SELECT Username,EmailID,TID FROM quantar_user WHERE UID=%s''';
    data = run_select_query(query, (sub,))
    print(data)
    return data
    

def lambda_handler(event, context):
    try:
        awsAccountId = os.environ["AwsAccountId"]
        roleArn = os.environ["RoleArn"]
        roleName = roleArn.split('/')[1]
        print(event)
        sub=event["sub"]
        is_team=event["is_team"]
        
        
        
        print(is_team)
        data=get_userName(sub)
        userName=data[0][0]
        
        # Read in the values passed to Lambda function
        openIdToken = event['IdToken']
        dashboardRegion = 'eu-west-2'
        # userName = event['userName']
        
        if userName == 'demouser':
            userName = 'DemoUser'
        
        # Assume role that has permissions on QuickSight
        sts = boto3.client('sts')
        assumedRole = sts.assume_role_with_web_identity(
            RoleArn=roleArn,
            RoleSessionName=userName,
            WebIdentityToken=openIdToken
        )
        
        print(assumedRole)
        
        assumedRoleSession = boto3.Session(
            aws_access_key_id=assumedRole['Credentials']['AccessKeyId'],
            aws_secret_access_key=assumedRole['Credentials']['SecretAccessKey'],
            aws_session_token=assumedRole['Credentials']['SessionToken'],
        )
        
        print(assumedRoleSession)
        quickSight = assumedRoleSession.client('quicksight',region_name= dashboardRegion)
        
        print(quickSight)
        
        if is_team is True:
            team_id=data[0][2]
            # #Generate Embed url
            response = quickSight.get_session_embed_url(
                AwsAccountId=awsAccountId,
                SessionLifetimeInMinutes=600,
                UserArn='arn:aws:quicksight:eu-west-2:'+awsAccountId+':user/default/'+roleName+'/'+team_id
                )
            return {
                    'statusCode': 200,
                    'QuickSightUrl': response['EmbedUrl']
                    }
        else:
            # #Generate Embed url
            response = quickSight.get_session_embed_url(
                AwsAccountId=awsAccountId,
                SessionLifetimeInMinutes=600,
                UserArn='arn:aws:quicksight:eu-west-2:'+awsAccountId+':user/default/'+roleName+'/'+userName
                )
            return {
                    'statusCode': 200,
                    'QuickSightUrl': response['EmbedUrl']
                    }
    except Exception as e:
        print(str(e))
        return {
        'statusCode': 400,
        'body': 'Failure: '+str(e)
        }