import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta
import pandas as pd


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def get_package_details(package_id):
    try:
        query = """SELECT * FROM quantar_user_management.quantar_package_mgmt where PacakageID = %s;"""
        data = run_select_query(query, (package_id,))
        df = pd.DataFrame(data, columns=[
                          'PackageName', 'PacakageID', 'packageDays', 'teamMemberCount', 'dataSetCount', 'Cost'])
        print(df)
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        return {}


def lambda_handler(event, context):
    try:
        print(event)
        package_id = event['params']['querystring']['package_id']
        data = get_package_details(package_id)
        return {
            'statusCode': 200,
            'data': data
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
