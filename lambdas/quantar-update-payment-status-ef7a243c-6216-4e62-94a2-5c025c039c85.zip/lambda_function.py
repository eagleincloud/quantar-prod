import json
import pymysql
import uuid
from datetime import datetime, timedelta


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def process_team_payment(event):
    
    InvoiceID = uuid.uuid4()
    transactionID = event['transactionID']
    TID = event['TID']
    UID = event['sub']
    payment_mode = event['PaymentMode']
    payment_status = event['PaymentStatus']
    packageId = event['PackageID']
    lastUpdateTimestamp = event['LastUpdateTimestamp']

    package_details_query = """SELECT * FROM quantar_user_management.quantar_package_mgmt where PacakageID = %s;"""

    package_details = run_select_query(package_details_query, (packageId,))

    if package_details:
        PackageName = package_details[0][0]
        PacakageID = package_details[0][1]
        packageDays = package_details[0][2]
        teamMemberCount = package_details[0][3]
        dataSetCount = package_details[0][4]
    else:
        raise Exception("Package Not Found")

    payment_history_query = """ INSERT INTO quantar_user_management.quantar_payment_history
        (InvoiceID, TID, UID, PaymentMode, PaymentStatus, PackageID, LastUpdateTimestamp, transactionID)
        VALUES(%s, %s, %s, %s, %s, %s, %s, %s);"""

    response = run_insert_update_query(payment_history_query, (InvoiceID, TID, UID,
                                                               payment_mode, payment_status, packageId, lastUpdateTimestamp, transactionID))

    if not response:
        raise Exception("Error in payment history insert")

    SubscriptionEndDate = datetime.strptime(
        lastUpdateTimestamp, '%y-%m-%d %H:%M:%S') + timedelta(days=packageDays)

    update_team_details = """UPDATE quantar_user_management.quantar_team
                             SET  PackageID=%s, LastUpdateTimestamp=%s, SubscriptionEndDate=%s
                             where TID=%s;
                          """
    response = run_insert_update_query(
        update_team_details, (PacakageID, lastUpdateTimestamp, SubscriptionEndDate, TID))

    if not response:
        raise Exception("Error in team update")

    update_user_details = """UPDATE quantar_user_management.quantar_user SET team_account_status=1 where TID=%s;"""

    response = run_insert_update_query(update_user_details, (TID,))

    if not response:
        raise Exception("Error in user management insert")
    
    return InvoiceID


def process_user_Payment(event):
    InvoiceID = uuid.uuid4()
    transactionID = event['transactionID']
    UID = event['sub']
    payment_mode = event['PaymentMode']
    payment_status = event['PaymentStatus']
    packageId = event['PackageID']
    lastUpdateTimestamp = event['LastUpdateTimestamp']

    package_details_query = """SELECT * FROM quantar_user_management.quantar_package_mgmt where PacakageID = %s;"""

    package_details = run_select_query(package_details_query, (packageId,))

    if package_details:
        PackageName = package_details[0][0]
        PacakageID = package_details[0][1]
        packageDays = package_details[0][2]
        teamMemberCount = package_details[0][3]
        dataSetCount = package_details[0][4]
    else:
        raise Exception("Package Not Found")

    payment_history_query = """ INSERT INTO quantar_user_management.quantar_payment_history
        (InvoiceID, UID, PaymentMode, PaymentStatus, PackageID, LastUpdateTimestamp, transactionID)
        VALUES(%s, %s, %s, %s, %s, %s, %s);"""

    response = run_insert_update_query(payment_history_query, (InvoiceID, UID,
                                                               payment_mode, payment_status, packageId, lastUpdateTimestamp, transactionID))

    if not response:
        raise Exception("Error in payment history insert")

    SubscriptionEndDate = datetime.strptime(
        lastUpdateTimestamp, '%y-%m-%d %H:%M:%S') + timedelta(days=packageDays)

    update_user_details = """UPDATE quantar_user_management.quantar_user SET individual_account_status=1 , SubscriptionEndDate = %s where UID=%s;"""

    response = run_insert_update_query(
        update_user_details, (SubscriptionEndDate, UID))

    if not response:
        raise Exception("Error in user management insert")
        
    return InvoiceID

def lambda_handler(event, context):
    try:
        # payment done for team or self individual
        payment_for = event['toggel_button_status']
        if payment_for.lower() == 'team':
            InvoiceID = process_team_payment(event)
        elif payment_for.lower() == 'self':
            InvoiceID = process_user_Payment(event)
        else:
            raise Exception('No Suitable Option Selected')
        
        return{
            'statusCode': 200,
            'body': 'Success',
            'InvoiceID' : str(InvoiceID)
        }
        
    except Exception as e:
        print("For Event: " + str(event))
        print("Error: " + str(e))
        return {
            'statusCode': 400,
            'body': json.dumps('Failure: '+str(e))
        }



