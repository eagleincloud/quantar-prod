import pymysql
import pandas as pd
import boto3
import io
import random
import re
import json

def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_select_query_with_values(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        


def check_team(sub):
    query='''SELECT TID FROM quantar_user WHERE UID=%s''';
    data = run_select_query_with_values(query, (sub,))
    print(data)
    return data
    
def get_file(sub,file_name):
    is_team=check_team(sub)
    
    if is_team[0][0] is not None:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IN 
        (SELECT TID FROM quantar_user WHERE UID=%s)''';
        data=run_select_query_with_values(query, (file_name,sub,))
        return data[0][0]
        
    else:
        query='''SELECT DatasetS3Path FROM quantar_user_dataset WHERE DatasetName =%s AND TID IS NULL''';
        data=run_select_query_with_values(query, (file_name,))
        return data[0][0]
        


def get_questions(keyword):
    try:
        query = "Select question from quantar_user_management.quantar_questions_skeleton where status = 1 and question like '%{}%';".format(
            keyword)
        print(query)
        data = run_select_query(query)
        print(data)
        df = pd.DataFrame(data, columns=['question', ])
        return df['question'].to_list()
    except Exception as e:
        print(str(e))
        raise Exception('Database Error: '+str(e))


root_ques = ['Can you please tell me the top', 'Can you please tell me the growth of', 'Can you please tell me where', 'Can you please tell me how much is the total of',
             'How much is', 'Can you please tell me how much is', 'How much do I have of', 'Can you please tell me the sum of', 'Can you please name me what are the top']


def group1(keyword, column_list):
    keyword = keyword.strip()
    if keyword.split(' ')[-1].isnumeric() and len(keyword.split(' ')) == 8:
        question_list = [keyword+" " + x + " by" for x in column_list]
        question_list = [q+" " + x  for q in question_list for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif len(keyword.split(' ')) == 7:
        question_list = [root_ques[0]+" " + x for x in ['5', '10']]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 9:
        question_list = [keyword+" by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 9:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        print(matching)
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif keyword.split(' ')[-1] in ['b','by'] and len(keyword.split(' ')) == 10:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 11:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 11:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }    
        
    
    else:
        question_list = get_questions(keyword)
        return {
            'statusCode': 200,
            'questions_list': question_list
        }


def group2(keyword, column_list):
    if keyword.split(' ')[-1] == 'of' and len(keyword.split(' ')) == 8:
        question_list = [
            keyword+" [column_item_name] between [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['b','by'] and len(keyword.split(' ')) == 14:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 15:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 15:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    elif len(keyword.split(' ')) > 15:
        question_list = get_questions(keyword)
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 9:
        question_list = [
            keyword+" between [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] == 'between' and len(keyword.split(' ')) == 10:
        question_list = [
            keyword+" [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] != 'between' and len(keyword.split(' ')) == 10:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" between [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }    
    elif len(keyword.split(' ')) == 11:
        question_list = [
            keyword+" to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['t','to'] and len(keyword.split(' ')) == 12:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 13:
        question_list = [
            keyword+" by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }    


def group3(keyword, column_list):
    if keyword.split(' ')[-1] == 'where' and len(keyword.split(' ')) == 6:
        question_list = [keyword+" [column item name] is "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    if len(keyword.split(' ')) == 7:
        question_list = [keyword+" is "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif keyword.split(' ')[-1] not in ['i','is'] and len(keyword.split(' ')) == 8:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" is "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    else:
        question_list = ["Can you please tell me where [column item name] is"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }


def group4(keyword, column_list):
    if keyword.split(' ')[-1] == 'of' and len(keyword.split(' ')) == 11:
        question_list = [keyword+" " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 12:
        question_list = [keyword]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 12:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }    
        
    else:
        question_list = [root_ques[3]+" " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }


def group6(keyword, column_list):
    if keyword.split(' ')[-1] == 'is' and len(keyword.split(' ')) == 3:
        question_list = [
            keyword+" [column_item_name] on [date]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 4:
        question_list = [
            keyword+" on [date]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 5 and keyword.split(' ')[-1] in ['o','on']:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" on [date]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 6 :
        question_list = [keyword]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }    
    else:
        question_list = [root_ques[5]]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }


def group7(keyword, column_list):
    if keyword.split(' ')[-1] == 'of' and len(keyword.split(' ')) == 6:
        question_list = [
            keyword+" [column_item_name]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    if len(keyword.split(' ')) == 7:
        question_list = [keyword]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }    
    else:
        question_list = [root_ques[6]]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }


def group8(keyword, column_list):
    print(len(keyword.split(' ')))
    if keyword.split(' ')[-1] == 'is' and len(keyword.split(' ')) == 8:
        question_list = [
            keyword+" " + x + " for [column_item_name] between [date_range1] to [date_range1]"for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 9:
        question_list = [
            keyword+" " + x + " for [column_item_name] between [date_range1] to [date_range1]"for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 9:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    elif keyword.split(' ')[-1] in ['f','fo','for'] and len(keyword.split(' ')) == 10:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" for [column_item_name] between [date_range1] to [date_range1]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 11:
        question_list = [
            keyword+" between [date_range1] to [date_range1]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['b','be','bet','betw','betwe','betwee','between'] and len(keyword.split(' ')) == 12:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" between [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 13:
        question_list = [
            keyword+" to [date_range1]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['t','to'] and len(keyword.split(' ')) == 14:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" to [date_range1]"]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 15:
        question_list = [keyword]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) > 15:
        question_list = [root_ques[5]]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }


def group9(keyword, column_list):
    if keyword.split(' ')[-1] == 'of' and len(keyword.split(' ')) == 8:
        question_list = [
            keyword+" [column_item_name] between [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['b','by'] and len(keyword.split(' ')) == 14:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 15:
        question_list = [keyword]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 15:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }  
    elif len(keyword.split(' ')) > 15:
        question_list = get_questions(keyword)
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 9:
        question_list = [
            keyword+" between [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['b','be','bet','betw','betwe','betwee','between'] and len(keyword.split(' ')) == 10:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" between [date_range1] to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 11:
        question_list = [
            keyword+" to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    
    elif len(keyword.split(' ')) == 13:
        question_list = [
            keyword+" by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    elif keyword.split(' ')[-1] in ['t','to'] and len(keyword.split(' ')) == 12:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [
            keyword+" to [date_range2] by "]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }


def group10(keyword, column_list):
    print(len(keyword.split(' ')))
    if keyword.split(' ')[-1].isnumeric() and len(keyword.split(' ')) == 10 :
        question_list = [keyword+" " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif len(keyword.split(' ')) == 9:
        question_list = [keyword+" " + x for x in ['5', '10']]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }    
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 11:
        question_list = [keyword+" per group by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 11:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x + " per group by " for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['p','pe','per'] and len(keyword.split(' ')) == 12:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" per group by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] in ['g','gr','gro','grou','group'] and len(keyword.split(' ')) == 13:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" group by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    elif keyword.split(' ')[-1] in ['b','by'] and len(keyword.split(' ')) == 14:
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" group by " + x for x in column_list]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    elif keyword.split(' ')[-1] in column_list and len(keyword.split(' ')) == 15:
        question_list = [keyword]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
    elif keyword.split(' ')[-1] not in column_list and len(keyword.split(' ')) == 15:
        matching = [s for s in column_list if keyword.split(' ')[-1] in s]
        keyword = keyword.rsplit(' ', 1)[0]
        question_list = [keyword+" " + x for x in matching]
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
    else:
        question_list = get_questions(keyword)
        return {
            'statusCode': 200,
            'questions_list': question_list
        }
        
def get_column_names(ColumnList,keyword, lastch, matchingList):
    query = "Select question from quantar_user_management.quantar_all_questions where status = 1 and question like '{}%' ;".format(
            keyword)
    print(query)
    
    data = run_select_query(query)
    print(data)
    df = pd.DataFrame(data, columns=['question', ])
        #return df['question'].to_list()

    print("DAtaframe:",df)
    Lines=df['question'].to_list()
    toReplace = "[Column Name]"
    JColumnList = ColumnList
    if len(matchingList) > 0:
        ColumnList = matchingList
        
    ReplaceQuestionsList = []
    unreplacable = set()
    # Strips the newline character
    for line in Lines:
        line = line.strip()
        if lastch != '0':
            line = line.replace('5', lastch)
        for i in ColumnList:
            if line.__contains__(toReplace):
                if line.count(toReplace) == 1:
                    repline = line.replace(toReplace, i)
                    ReplaceQuestionsList.append(repline)
                elif line.count(toReplace) == 2:
                    for j in JColumnList:
                        repline = line.replace(toReplace, i, 1).replace(toReplace, j)
                        ReplaceQuestionsList.append(repline)
            else:
                unreplacable.add(line)
    
    for i in unreplacable:
        ReplaceQuestionsList.append(i)
    print('length', len(ReplaceQuestionsList))
    
    if len(ReplaceQuestionsList) > 15:
        ReplaceQuestionsList = random.sample(ReplaceQuestionsList, 15)
    print(ReplaceQuestionsList)
    
    return ReplaceQuestionsList


def lambda_handler(event, context):
    try:
        print(event)
        keyword = event['sentence']
        keyword=keyword[0].upper() + keyword[1:]
        sub = event['sub']
        file_name = event['filename']
        keyword = keyword.strip()
        bucket_name = 'quantar-production-bucket'
        #folder_name=filename.split('.')[0]
        
        file_path = get_file(sub,file_name)
        object_key="/".join(file_path.split('/')[3:])
        
        # object_key = sub+'/'+folder_name+'/'+filename

        s3c = boto3.client('s3')

        obj = s3c.get_object(Bucket=bucket_name, Key=object_key)

        df = pd.read_csv(io.BytesIO(obj['Body'].read()), encoding='latin-1')
        print("DF ",df)

        column_list = df.columns.values
        
        if keyword != '':
            
            delim='0'
            toReplace = "[Column Name]"
            num = '5'
            matchingList = []
            for i in keyword.split(' '):
                if i.isnumeric():
                    delim = i
                    keyword = keyword.replace(delim, num)
                    
                # elif re.search(i, ''.join(column_list), re.IGNORECASE):
                #     keyword=keyword.replace(i,toReplace)
                #     for j in column_list:
                #         if re.search(i, j, re.IGNORECASE):
                #             matchingList.append(j)
                elif len(list(filter(lambda x: i in x, column_list))) > 0:
                    print(matchingList)
                    matchingList = list(filter(lambda x: i in x, column_list))
                    keyword=keyword.replace(i,toReplace)
                    
            print (keyword, delim)
            question_response=get_column_names(column_list,keyword, delim, matchingList)
            print("Response: ",question_response)
            
            return {
                'statusCode': 200,
                'questions_list': question_response
            }
        elif keyword == '':
            print(keyword)
        

            if keyword.find(root_ques[0]) == 0:
                print("Group1")
                return group1(keyword, column_list)
            elif keyword.find(root_ques[1]) == 0:
                print("Group2")
                return group2(keyword, column_list)
            elif keyword.find(root_ques[2]) == 0:
                print("Group3")
                return group3(keyword, column_list)
            elif keyword.find(root_ques[3]) == 0:
                print("Group4")
                return group4(keyword, column_list)
            elif keyword.find(root_ques[4]) == 0:
                print("Group6")    
                return group6(keyword, column_list)
            elif keyword.find(root_ques[6]) == 0:
                print("Group7")
                return group7(keyword, column_list)
            elif keyword.find(root_ques[5]) == 0:
                print("Group8")
                return group8(keyword, column_list)
            elif keyword.find(root_ques[7]) == 0:
                print("Group9")
                return group9(keyword, column_list)
            elif keyword.find(root_ques[8]) == 0:
                print("Group10")
                return group10(keyword, column_list)
            else:
                print('DB')
                question_list = get_questions(keyword)
                return {
                    'statusCode': 200,
                    'questions_list': question_list
                }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body': "Error in Question Generator. {}".format(str(e))
        }
