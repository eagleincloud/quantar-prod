import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def create_s3_folder(TID):
    s3 = boto3.client('s3')
    bucket_name = "quantar-production-bucket"
    key = TID+"/"
    s3.put_object(Bucket=bucket_name, Key=key)


def update_team_id_for_user(TID, UID):
    user_update_query = """UPDATE quantar_user_management.quantar_user SET TID=%s, team_account_status=1,  team_account_exist=0 where UID=%s;"""
    return run_insert_update_query(user_update_query, (TID, UID))


def check_user_associated_team(UID):
    team_check_query = """SELECT TID, team_account_status, team_account_exist FROM quantar_user_management.quantar_user where UID = %s;"""
    data = run_select_query(team_check_query, (UID,))
    TID = data[0][0]
    team_account_status = data[0][1]
    team_account_exist = data[0][2]
    if TID:
        return True
    else:
        return False


def lambda_handler(event, context):
    try:
        TID = str(uuid.uuid4())
        team_name = event['team_name']
        UID = event['sub']
        if check_user_associated_team(UID):
            raise Exception('User is already associated with a team')

        if not update_team_id_for_user(TID, UID):
            raise Exception('Error in recording entry.')

        # create_s3_folder(TID)

        return {
            'statusCode': 200,
            'Team_ID': TID,
            'body': json.dumps('Make Payment For Team Features')
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps(str(e))
        }
