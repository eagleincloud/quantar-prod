import json
import pymysql
from datetime import datetime, timedelta
import pandas as pd
import boto3

def get_user_role(UID):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """SELECT URID as user_role 
                   FROM quantar_user_management.quantar_user WHERE UID = '{}';""".format(UID)
        cur.execute(query)
        records = cur.fetchone()[0]
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def run_select_query(query, values):
    print("Inside Run select")
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def get_payment_invoice(is_team,id):
    print("Inside Get_payment_Invoice")
    try:
        if is_team.upper() == "TRUE":
            print("Inside True")
            query = """SELECT * FROM quantar_user_management.quantar_payment_history WHERE TID in (SELECT TID FROM quantar_user_management.quantar_payment_history WHERE UID = %s);"""
            output = run_select_query(query, (id,))
            df = pd.DataFrame(output, columns=['InvoiceID','TID',	'UID','URID','PaymentMode',	'PaymentStatus', 'PackageID', 'PaymentDate', 'transactionID', 'PaidAmount'])
            df['PaymentDate']=df['PaymentDate'].astype(str)
            print(df)
            return df
        else:
            print("Inside False")
            query = """SELECT * FROM quantar_user_management.quantar_payment_history WHERE UID = %s;"""
            output = run_select_query(query, (id,))
            df = pd.DataFrame(output, columns=['InvoiceID','TID',	'UID','URID','PaymentMode',	'PaymentStatus', 'PackageID', 'PaymentDate', 'transactionID', 'PaidAmount'])
            print(df)                  
            return df
            
    except Exception as e:
        print(str(e))
        raise Exception('Database Error: '+str(e))
         
            
        
def lambda_handler(event, context):
    print(event)
    UID = event['params']['querystring']['sub']  # get method
    role = get_user_role(UID)
    print(role)
    if role == "TeamAdmin" or role == "TeamUser":
        return {
            'statusCode': 400,
            'body': 'User does not have specefic Permission'
        }
    try:
        id = event['params']['querystring']['sub']
        is_team = str(event['params']['querystring']['is_team'])
        
        data=get_payment_invoice(is_team,id)
        value=data.to_dict('records')
               
        return {
            'statusCode': 200,
            'data': value,
            'file': None
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 200,
            'body': 'Failure: '+str(e)
        }

