import json
import pymysql
import pandas as pd

def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        
def get_nlp_history(id,file_name):
    try:
        query=''' SELECT question,timestamp FROM quantar_user_management.quantar_nlp_history WHERE User_id=%s and dataset=%s ORDER BY TIMESTAMP DESC; '''
        
        data=run_select_query(query,(id,file_name))
        df = pd.DataFrame(data, columns=['Question','Timestamp'])
        
        print(df)                  
        return df.to_dict('records')
        
    except Exception as e:
        raise Exception('Database Error: '+str(e))

    
def lambda_handler(event, context):
    try:
        print(event)
        id = event['params']['querystring']['sub']
        file_name=event['params']['querystring']['file_name']
        history = get_nlp_history(id,file_name)
        return {
            'statusCode': 200,
            'data': history
        }

    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
