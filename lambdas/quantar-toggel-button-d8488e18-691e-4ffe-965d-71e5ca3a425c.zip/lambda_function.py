import pymysql


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchone()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
    


def get_team_id(UID):
    query = """SELECT TID FROM quantar_user_management.quantar_user where UID  = %s;"""
    response = run_select_query(
        query, (UID,))

    return response

def get_user_role(UID):
    query = """SELECT URID FROM quantar_user_management.quantar_user where UID  = %s;"""
    response = run_select_query(
        query, (UID,))

    return response
    

def lambda_handler(event, context):
    try:
        sub = event['sub']
        role=get_user_role(sub)
        t = get_team_id(sub)

        
        if None not in t:
            return {
                'statusCode': 200,
                'team_id': t[0],
                'role': role[0],
                'team_present': True
            }
        else:
            return {
                'statusCode': 200,
                'team_id': 'No Team Associated with the user.',
                'team_present': False
            }
    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
