import pymysql
import pandas as pd
import json

def run_select_query(query):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def get_rules(UID):
    try:
        query = """SELECT ALLOWED_API_LIST 
                    FROM quantar_user_management.quantar_user_role_rules qurr
                    Join quantar_user_management.quantar_user qum
                    on qum.URID = qurr.Role_Name 
                    where qum.UID =  '{}';""".format(UID)
        print(query)
        data = run_select_query(query)
        print(data)
        return data[0][0]
    except Exception as e:
        print(str(e))
        raise Exception('Database Error')


def lambda_handler(event, context):
    try:
        UID = event['params']['querystring']['sub']
        data = get_rules(UID)
        return {
            'statusCode': 200,
            'body': json.loads(data)
        }
    except Exception as e:
        print(str(e))
        return {
            'statusCode': 400,
            'body': 'Error in the fetching user rules. Message: {0}'.format(str(e))
        }
