import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta
import pandas as pd


def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()


def update_package(package_id, update_attributes, attribute_values):
    query_part1 = "Update quantar_user_management.quantar_package_mgmt set "
    query_part2 = ' , '.join(update_attributes)
    query_part3 = " where PacakageID = %s;"
    query = query_part1 + query_part2 + query_part3
    attribute_values.append(package_id)
    return run_insert_update_query(query, tuple(attribute_values))


def lambda_handler(event, context):
    try:
        operation_type = event['operation_type']
        if  operation_type == 'update':
            package_id = event['package_id']
            update_attributes = []
            attribute_values = []
            if 'PackageName' in event:
                update_attributes.append('PackageName = %s')
                attribute_values.append(event['PackageName'])

            if 'packageDays' in event:
                update_attributes.append('packageDays = %s')
                attribute_values.append(int(event['packageDays']))

            if 'teamMemberCount' in event:
                update_attributes.append('teamMemberCount = %s')
                attribute_values.append(int(event['teamMemberCount']))

            if 'dataSetCount' in event:
                update_attributes.append('dataSetCount = %s')
                attribute_values.append(int(event['dataSetCount']))

            if 'Cost' in event:
                update_attributes.append('Cost = %s')
                attribute_values.append(float(event['Cost']))

            if update_attributes:
                response = update_package(
                    package_id, update_attributes, attribute_values)
                return {
                    'statusCode': 200,
                    'isPackageUpdated': response
                }
            else:
                return {
                    'statusCode': 200,
                    'isPackageAdded': False
                }
        else:
            raise Exception('Wrong Operation')
    except Exception as e:
        return {
            'statusCode': 400,
            'error': str(e)
        }
