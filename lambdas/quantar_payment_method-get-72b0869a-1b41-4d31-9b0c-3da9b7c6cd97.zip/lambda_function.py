import json
import pymysql
import uuid
import boto3
from datetime import datetime, timedelta
import pandas as pd

def get_user_role(UID):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        query = """SELECT URID as user_role 
                   FROM quantar_user_management.quantar_user WHERE UID = '{}';""".format(UID)
        cur.execute(query)
        records = cur.fetchone()[0]
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()
        
def run_select_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        records = cur.fetchall()
        return records
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

        
def get_card_details(user_id):
    try:
        query = """SELECT * FROM quantar_user_management.quantar_payment_method where UserID = %s;"""
        data = run_select_query(query, (user_id,))
        df = pd.DataFrame(data, columns=[
                          'ID', 'CardType', 'CardNumber', 'CardExpiry', 'HolderName', 'UserID'])
        return df.to_dict('records')
    except Exception as e:
        print(str(e))
        return {}
        
def lambda_handler(event, context):
    try:
        print(event)
        UID = event['params']['querystring']['sub']  # get method
        role = get_user_role(UID)
        print(role)
        if role == "TeamAdmin" or role == "TeamUser":
            return {
                'statusCode': 400,
                'body': 'User does not have specefic Permission'
            }
        
        user_id = event['params']['querystring']['sub']
        data = get_card_details(user_id)
        return {
            'statusCode': 200,
            'body': data
        }
      
    except Exception as e:
        return {
            'statusCode': 400,
            'Error': str(e)
        }
