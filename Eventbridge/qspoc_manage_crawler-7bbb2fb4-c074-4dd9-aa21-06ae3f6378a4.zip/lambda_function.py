import boto3
import time
import pymysql

def get_qs_user_id(sourceKey):
    identity = sourceKey.split("/")[3]
    client = boto3.client('cognito-idp')
    response = client.list_users(
        UserPoolId='eu-west-2_8ne74JB2A',
        Filter="sub = '"+identity+"'"
    )
    return response['Users']

def run_insert_update_query(query, values):
    try:
        conn = pymysql.connect(
            host='quantar-production-database.c3rldrolms0k.eu-west-2.rds.amazonaws.com',
            user='quantar_admin',
            password="fuSPFRpovgpLpjP8lVBO",
            db='quantar_user_management',
        )
        cur = conn.cursor()
        # Insert query
        cur.execute(query, values)
        conn.commit()
        return True
    except Exception as e:
        print(str(e))
        return False
    finally:
        conn.close()

def get_s3_object_tag_team_status(file_location, tableName):
    client = boto3.client('s3')
    bucket_name = file_location.split('/')[2]
    key = '/'.join(file_location.split('/')[3:])+tableName+'.csv'
    
    response = client.get_object_tagging(
    Bucket=bucket_name,
    Key=key)
    
    tag_list = response['TagSet']
    
    is_team = False
    
    if tag_list:
        for i in tag_list:
            if i['Key'] == 'is_team':
                is_team = i['Value']
    
    return is_team
        
def lambda_handler(event, context):
    try:
        print(event)
        if event['detail']['typeOfChange'] == 'UpdateTable':
            tableName = event['detail']['tableName']
        elif event['detail']['typeOfChange'] == 'CreateTable':
            tableName = event['detail']['changedTables'][0]
        else:
            crawler_name=None
            return {
                    'statusCode': 400,
                    'Msg': 'Invalid Operation'
                }
        
        databaseName = event['detail']['databaseName']
        client = boto3.client('glue')
        response = client.get_table(
            DatabaseName=databaseName,
            Name=tableName
        )
        columns = column_data_type_converter(
            response['Table']['StorageDescriptor']['Columns'])
        file_location = response['Table']['StorageDescriptor']['Location']
        crawler_name = response['Table']['Parameters']['UPDATED_BY_CRAWLER']
        print(columns, file_location, crawler_name)
        user = get_qs_user_id(file_location)
        qs_user_name = user[0]['Username']
        
        is_team = get_s3_object_tag_team_status(file_location, tableName)
        
        if qs_user_name.lower() == 'demouser':
            qs_user_name = 'DemoUser'
            
        qs_role_name = 'QSERqspoc'
        
        if is_team:
            team=get_team(qs_user_name)
            print("Team Present: ", team)
            qs_user_name = team
            
        else:
            print("Team Absent")
            
        data_source_id = 'data-source1-'+qs_user_name
        describe_or_create_qs_datasource(qs_user_name, qs_role_name)
        SqlQuery = 'SELECT * FROM '+databaseName+'.'+tableName
        create_quicksight_dataset(
            columns, SqlQuery, tableName, data_source_id, qs_role_name, qs_user_name,file_location)
    except Exception as e:
        print(str(e))
    finally:
        delete_glue_crawler(crawler_name)


def column_data_type_converter(columns):
    for col in columns:
        if col['Type'] == 'bigint':
            col['Type'] = 'INTEGER'
        if col['Type'] == 'string':
            col['Type'] = 'STRING'
        if col['Type'] == 'double':
            col['Type'] = 'DECIMAL'
    return columns


def describe_or_create_qs_datasource(qs_user_name, qs_role_name):
    try:
        client = boto3.client('quicksight')
        response = client.create_data_source(
            AwsAccountId='625302196318',
            DataSourceId='data-source1-'+qs_user_name,
            Name='data-source1-'+qs_user_name,
            Type='ATHENA',
            Permissions=[
                {
                    'Principal': 'arn:aws:quicksight:eu-west-2:625302196318:user/default/'+qs_role_name+'/'+qs_user_name,
                    'Actions': ["quicksight:UpdateDataSourcePermissions",
                                "quicksight:DescribeDataSource",
                                "quicksight:DescribeDataSourcePermissions",
                                "quicksight:PassDataSource",
                                "quicksight:UpdateDataSource",
                                "quicksight:DeleteDataSource"
                                ]
                },
            ]
        )
        return response
    except Exception as e:
        print(str(e))

def update_db(uid,dataset_name,tableName):
    query='''UPDATE `quantar_user_dataset` SET QuickSight_Dataset_Name='{}' WHERE UID='{}' AND
    DatasetName LIKE '{}%'; '''.format(dataset_name,uid,tableName)
    
    response=run_insert_update_query(query,None)
    print("Table Updated: ",response)

def get_team(sub):
    query='''SELECT TID FROM quantar_user WHERE Username=%s''';
    data = run_select_query(query, (sub,))
    print(data)
    return data[0][0]    

def create_quicksight_dataset(columns, SqlQuery, tableName, data_source_id, qs_role_name, qs_user_name,file_location):
    try:
        import datetime
        x = datetime.datetime.now()
        timstmp='{}-{}-{}-{}-{}'.format(x.year,x.month,x.day,x.hour,x.minute)
        #timstmp = time.time()
        #timstmp = "test"
        client = boto3.client('quicksight')
        uid = file_location.split("/")[3]
        dataset_name=tableName+ timstmp+ '-data-set'
        update_db(uid,dataset_name,tableName)
        response = client.create_data_set(
            AwsAccountId='625302196318',
            DataSetId=dataset_name,
            Name=dataset_name,
            PhysicalTableMap={"quantar-quicksight-data-set-query": {
                'CustomSql': {
                    'DataSourceArn': 'arn:aws:quicksight:eu-west-2:625302196318:datasource/'+data_source_id,
                    'Name': 'custom query test',
                    'SqlQuery': SqlQuery,
                    'Columns': columns
                }
            }},
            ImportMode='DIRECT_QUERY',
            Permissions=[
                {
                    'Principal': 'arn:aws:quicksight:eu-west-2:625302196318:user/default/'+qs_role_name+'/'+qs_user_name,
                    'Actions': ["quicksight:UpdateDataSetPermissions",
                                "quicksight:DescribeDataSet",
                                "quicksight:DescribeDataSetPermissions",
                                "quicksight:PassDataSet",
                                "quicksight:DescribeIngestion",
                                "quicksight:ListIngestions",
                                "quicksight:UpdateDataSet",
                                "quicksight:DeleteDataSet",
                                "quicksight:CreateIngestion",
                                "quicksight:CancelIngestion"
                                ]
                },
            ]
        )
        return response
    except Exception as e:
        print(str(e))


def delete_glue_crawler(crawler_name):
    try:
        time.sleep(120)
        client = boto3.client('glue')
        response = client.delete_crawler(
            Name=crawler_name
        )
    except Exception as e:
        print(str(e))
